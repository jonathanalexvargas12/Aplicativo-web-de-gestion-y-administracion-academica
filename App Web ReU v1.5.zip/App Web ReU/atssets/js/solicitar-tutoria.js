//Paginacion y filtrado

document.addEventListener('DOMContentLoaded', () => {
    const tablaSolicitudes = document.getElementById('tabla-solicitudes').getElementsByTagName('tbody')[0];
    const buscarInputSolicitudes = document.querySelector('.buscar-input-solicitudes');
    const estatusSelectSolicitudes = document.querySelector('.estatus-select-solicitudes');
    const btnBuscarSolicitudes = document.querySelector('.btn-buscar-solicitudes');
    const btnReajustarSolicitudes = document.querySelector('.btn-reajustar-solicitudes');

    let filasOriginalesSolicitudes = [];

    function guardarFilasOriginales() {
        filasOriginalesSolicitudes = Array.from(tablaSolicitudes.rows).map(row => row.cloneNode(true));
    }

    guardarFilasOriginales();

    function filtrarTablaSolicitudes() {
        const textoBusqueda = buscarInputSolicitudes.value.toLowerCase();
        const estatusSeleccionado = estatusSelectSolicitudes.value;

        tablaSolicitudes.innerHTML = '';

        filasOriginalesSolicitudes.forEach(filaOriginal => {
            const fechaSolicitud = filaOriginal.cells[1].textContent.toLowerCase();
            const tutorSolicitar = filaOriginal.cells[2].textContent.toLowerCase();
            const solicitadoPor = filaOriginal.cells[3].textContent.toLowerCase();
            const estatusTexto = filaOriginal.cells[4].textContent.trim().toLowerCase();

            const coincideBusqueda = textoBusqueda === '' ||
                fechaSolicitud.includes(textoBusqueda) ||
                tutorSolicitar.includes(textoBusqueda) ||
                solicitadoPor.includes(textoBusqueda);
            const coincideEstatus = estatusSeleccionado === '' || estatusTexto.includes(estatusSeleccionado);

            if (coincideBusqueda && coincideEstatus) {
                tablaSolicitudes.appendChild(filaOriginal.cloneNode(true));
            }
        });
        inicializarPaginacionTutoria(); // Reinicializar la paginación después de filtrar
    }

    function inicializarPaginacionTutoria() {
        const tabla = document.getElementById('tabla-solicitudes').getElementsByTagName('tbody')[0];
        if (!tabla) return;

        const filas = Array.from(tabla.getElementsByTagName('tr'));
        const numFilasPorPagina = 5;
        let paginaActual = 1;
        let numPaginas = Math.ceil(filas.length / numFilasPorPagina);

        const numerosPaginaDiv = document.querySelector('.numeros-pagina-tutoria');
        const infoPaginacionSpan = document.querySelector('.info-paginacion-tutoria');
        const btnAnterior = document.querySelector('.pagina-anterior-tutoria');
        const btnSiguiente = document.querySelector('.pagina-siguiente-tutoria');

        if (!numerosPaginaDiv || !infoPaginacionSpan || !btnAnterior || !btnSiguiente) return;

        function mostrarPagina(numPagina) {
            paginaActual = numPagina;
            const inicio = (numPagina - 1) * numFilasPorPagina;
            const fin = Math.min(inicio + numFilasPorPagina, filas.length);

            filas.forEach((fila, index) => {
                fila.style.display = (index >= inicio && index < fin) ? 'table-row' : 'none';
            });

            actualizarNumerosPagina();
            actualizarInfoPaginacion();
        }

        function actualizarNumerosPagina() {
            numerosPaginaDiv.innerHTML = '';
            numPaginas = Math.ceil(filas.length / numFilasPorPagina);

            for (let i = 1; i <= numPaginas; i++) {
                const btnNumero = document.createElement('button');
                btnNumero.classList.add('numero-pagina-tutoria');
                btnNumero.textContent = i;
                btnNumero.dataset.pagina = i;

                if (i === paginaActual) {
                    btnNumero.classList.add('activo');
                }

                btnNumero.addEventListener('click', (event) => {
                    mostrarPagina(parseInt(event.target.dataset.pagina));
                });

                numerosPaginaDiv.appendChild(btnNumero);
            }
        }

        function actualizarInfoPaginacion() {
            const inicio = (paginaActual - 1) * numFilasPorPagina + 1;
            const fin = Math.min(paginaActual * numFilasPorPagina, filas.length);
            infoPaginacionSpan.textContent = `${inicio}-${fin} de ${filas.length}`;

            btnAnterior.disabled = paginaActual === 1;
            btnSiguiente.disabled = paginaActual === numPaginas || numPaginas === 0;
        }

        btnAnterior.addEventListener('click', () => {
            if (paginaActual > 1) {
                mostrarPagina(paginaActual - 1);
            }
        });

        btnSiguiente.addEventListener('click', () => {
            if (paginaActual < numPaginas) {
                mostrarPagina(paginaActual + 1);
            }
        });

        if (filas.length > 0) {
            mostrarPagina(1);
            actualizarNumerosPagina();
        } else {
            infoPaginacionSpan.textContent = "0-0 de 0";
            btnAnterior.disabled = true;
            btnSiguiente.disabled = true;
        }
    }

    btnReajustarSolicitudes.addEventListener('click', () => {
        buscarInputSolicitudes.value = '';
        estatusSelectSolicitudes.selectedIndex = 0;
        tablaSolicitudes.innerHTML = '';
        filasOriginalesSolicitudes.forEach(fila => tablaSolicitudes.appendChild(fila.cloneNode(true)));
        inicializarPaginacionTutoria(); // Reinicializar la paginación después de reajustar
    });

    btnBuscarSolicitudes.addEventListener('click', filtrarTablaSolicitudes);

    inicializarPaginacionTutoria(); // Inicializar la paginación al cargar la página
});

// Ventana modal de Agregar

const agregarModal = document.getElementById("agregarModal");
const agregarModalForm = document.getElementById("agregar-modal-form");
const agregarClose = document.getElementsByClassName("agregar-close")[0];
const cancelarAgregarModal = document.getElementById("cancelar-agregar-modal");
const btnAgregarSolicitud = document.getElementById("btn-agregar-solicitud"); // Botón "Agregar" en el CRUD

// Abrir la ventana modal de agregar al hacer clic en el botón "Agregar"
btnAgregarSolicitud.addEventListener("click", () => {
    agregarModal.style.display = "block";
});

// Cerrar la ventana modal de agregar
agregarClose.onclick = function() {
    agregarModal.style.display = "none";
};

cancelarAgregarModal.onclick = function() {
    agregarModal.style.display = "none";
};

window.onclick = function(event) {
    if (event.target == agregarModal) {
        agregarModal.style.display = "none";
    }
};

// Manejar el envío del formulario de agregar
agregarModalForm.addEventListener('submit', (event) => {
    event.preventDefault();

    // Obtener los valores del formulario
    const fechaSolicitud = document.getElementById("agregar-fecha-solicitud").value;
    const tutorSolicitado = document.getElementById("agregar-tutor-solicitado").value;
    const solicitadoPor = document.getElementById("agregar-solicitado-por").value;
    const estatus = document.getElementById("agregar-estatus").value;

    // Crear una nueva fila en la tabla
    const tablaSolicitudes = document.getElementById("tabla-solicitudes").getElementsByTagName("tbody")[0];
    const nuevaFila = tablaSolicitudes.insertRow();

    // Añadir las celdas con los datos
    const celdaNumero = nuevaFila.insertCell(0);
    const celdaFecha = nuevaFila.insertCell(1);
    const celdaTutor = nuevaFila.insertCell(2);
    const celdaSolicitadoPor = nuevaFila.insertCell(3);
    const celdaEstatus = nuevaFila.insertCell(4);
    const celdaAcciones = nuevaFila.insertCell(5);

    // Número de la fila (autoincremental)
    celdaNumero.textContent = tablaSolicitudes.rows.length;

    // Datos de la nueva solicitud
    celdaFecha.textContent = fechaSolicitud;
    celdaTutor.textContent = tutorSolicitado;
    celdaSolicitadoPor.textContent = solicitadoPor;
    celdaEstatus.innerHTML = `<span class="estatus-circulo solicitud-${estatus}"></span> Solicitud ${estatus.charAt(0).toUpperCase() + estatus.slice(1)}`;


    // Cerrar el modal
    agregarModal.style.display = "none";

    // Limpiar el formulario
    agregarModalForm.reset();
});


// Ventana modal de Eliminar 

const eliminarModal = document.getElementById("eliminarModal");
const eliminarClose = document.getElementsByClassName("eliminar-close")[0];
const btnCancelarEliminar = document.getElementById("btn-cancelar-eliminar");
const btnAceptarEliminar = document.getElementById("btn-aceptar-eliminar");
const eliminarIcons = document.querySelectorAll(".eliminar-icono"); // Íconos de eliminar en la tabla
let currentRow; // Fila actual que se está eliminando

// Abrir la ventana modal de eliminar al hacer clic en el ícono de eliminar
eliminarIcons.forEach(icon => {
    icon.addEventListener("click", (event) => {
        eliminarModal.style.display = "block";
        currentRow = event.target.closest("tr"); // Obtener la fila actual
    });
});

// Cerrar la ventana modal de eliminar
eliminarClose.onclick = function() {
    eliminarModal.style.display = "none";
};

btnCancelarEliminar.onclick = function() {
    eliminarModal.style.display = "none";
};

window.onclick = function(event) {
    if (event.target == eliminarModal) {
        eliminarModal.style.display = "none";
    }
};

// Manejar la eliminación de la fila
btnAceptarEliminar.addEventListener("click", () => {
    if (currentRow) {
        currentRow.remove(); // Eliminar la fila de la tabla
        eliminarModal.style.display = "none"; // Cerrar el modal
    }
});

