-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         11.7.2-MariaDB - mariadb.org binary distribution
-- SO del servidor:              Win64
-- HeidiSQL Versión:             12.10.0.7000
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Volcando estructura de base de datos para reu_db
CREATE DATABASE IF NOT EXISTS `reu_db` /*!40100 DEFAULT CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci */;
USE `reu_db`;

-- Volcando estructura para tabla reu_db.asignaturas
CREATE TABLE IF NOT EXISTS `asignaturas` (
  `Codigo_Asignatura` varchar(13) NOT NULL COMMENT 'Formato: FFF000 o FFFIII000 o FFF-FFFIII000',
  `Nombre_Asignatura` varchar(20) NOT NULL,
  `Carrera` varchar(13) NOT NULL COMMENT 'Formato: FFF000',
  `Trayecto` int(1) NOT NULL,
  `Sem/Trim` int(1) NOT NULL,
  `Valor_UC` int(2) NOT NULL COMMENT 'Valor de Unidades de Credito',
  PRIMARY KEY (`Codigo_Asignatura`),
  KEY `Carrera` (`Carrera`),
  CONSTRAINT `Carrera` FOREIGN KEY (`Carrera`) REFERENCES `carreras` (`Codigo_Carrera`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;

-- Volcando datos para la tabla reu_db.asignaturas: ~3 rows (aproximadamente)
REPLACE INTO `asignaturas` (`Codigo_Asignatura`, `Nombre_Asignatura`, `Carrera`, `Trayecto`, `Sem/Trim`, `Valor_UC`) VALUES
	('ING-001', 'Ingles I', 'P-INF-2025', 1, 2, 25),
	('MAT-001', 'Matematica I', 'P-INF-2025', 1, 2, 20),
	('RED-001', 'Redes', 'P-INF-2025', 1, 2, 20);

-- Volcando estructura para tabla reu_db.aulas
CREATE TABLE IF NOT EXISTS `aulas` (
  `Nombre_Aula` varchar(12) NOT NULL COMMENT 'Ejemplo: Aula-01, Virtual-01 etc..',
  `Capacidad` int(2) NOT NULL,
  PRIMARY KEY (`Nombre_Aula`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;

-- Volcando datos para la tabla reu_db.aulas: ~6 rows (aproximadamente)
REPLACE INTO `aulas` (`Nombre_Aula`, `Capacidad`) VALUES
	('Aula 04', 30),
	('Aula 05', 21),
	('Aula 08', 30),
	('Aula 11', 30),
	('Aula 111', 30),
	('Aula 12', 35);

-- Volcando estructura para tabla reu_db.bitacora
CREATE TABLE IF NOT EXISTS `bitacora` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Fecha` date NOT NULL,
  `Hora` varchar(15) NOT NULL DEFAULT '',
  `IP` varchar(45) NOT NULL,
  `Usuario_ID` varchar(20) NOT NULL,
  `Accion` varchar(100) NOT NULL,
  `Fecha_Registro` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`ID`),
  KEY `FK_bitacora_usuarios` (`Usuario_ID`),
  CONSTRAINT `FK_bitacora_usuarios` FOREIGN KEY (`Usuario_ID`) REFERENCES `usuarios` (`ID_Usuario`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=279 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;

-- Volcando datos para la tabla reu_db.bitacora: ~54 rows (aproximadamente)
REPLACE INTO `bitacora` (`ID`, `Fecha`, `Hora`, `IP`, `Usuario_ID`, `Accion`, `Fecha_Registro`) VALUES
	(214, '2025-06-06', '12:21:33', '87.249.132.153', 'JONATHAV', 'Inicio de Sesión', '2025-06-06 16:21:33'),
	(215, '2025-06-06', '12:30:22', '87.249.132.153', 'JONATHAV', 'Inicio de Sesión', '2025-06-06 16:30:22'),
	(216, '2025-06-06', '12:52:50', '87.249.132.153', 'JONATHAV', 'Inicio de Sesión', '2025-06-06 16:52:50'),
	(217, '2025-06-06', '12:53:21', '87.249.132.153', 'JONATHAV', 'Cierre de Sesión', '2025-06-06 16:53:21'),
	(218, '2025-06-06', '13:48:53', '38.196.193.217', 'JONATHAV', 'Inicio de Sesión', '2025-06-06 17:48:53'),
	(219, '2025-06-06', '14:20:36', '38.196.193.217', 'JONATHAV', 'Inicio de Sesión', '2025-06-06 18:20:36'),
	(220, '2025-06-06', '14:31:28', '38.196.193.217', 'JONATHAV', 'Inicio de Sesión', '2025-06-06 18:31:28'),
	(221, '2025-06-06', '14:31:29', '38.196.193.217', 'JONATHAV', 'Inicio de Sesión', '2025-06-06 18:31:29'),
	(222, '2025-06-06', '14:57:18', '38.196.193.217', 'JONATHAV', 'Cierre de Sesión', '2025-06-06 18:57:18'),
	(223, '2025-06-06', '14:57:22', '38.196.193.217', 'JONATHAV', 'Inicio de Sesión', '2025-06-06 18:57:22'),
	(224, '2025-06-06', '14:57:26', '38.196.193.217', 'JONATHAV', 'Cierre de Sesión', '2025-06-06 18:57:26'),
	(225, '2025-06-06', '14:57:42', '38.196.193.217', 'JONATHAV', 'Inicio de Sesión', '2025-06-06 18:57:42'),
	(226, '2025-06-06', '15:06:23', '38.196.193.217', 'JONATHAV', 'Cierre de Sesión', '2025-06-06 19:06:23'),
	(227, '2025-06-06', '15:25:51', '38.196.193.220', 'JONATHAV', 'Inicio de Sesión', '2025-06-06 19:25:51'),
	(228, '2025-06-06', '15:25:51', '38.196.193.220', 'JONATHAV', 'Inicio de Sesión', '2025-06-06 19:25:51'),
	(229, '2025-06-06', '15:25:57', '38.196.193.220', 'JONATHAV', 'Cierre de Sesión', '2025-06-06 19:25:57'),
	(230, '2025-06-06', '15:26:02', '38.196.193.220', 'JONATHAV', 'Inicio de Sesión', '2025-06-06 19:26:02'),
	(232, '2025-06-06', '21:23:56', '38.196.193.218', 'JONATHAV', 'Inicio de Sesión', '2025-06-07 01:23:56'),
	(233, '2025-06-06', '21:35:26', '38.196.193.220', 'JONATHAV', 'Inicio de Sesión', '2025-06-07 01:35:26'),
	(234, '2025-06-06', '21:43:47', '38.196.193.218', 'JONATHAV', 'Inicio de Sesión', '2025-06-07 01:43:47'),
	(235, '2025-06-06', '21:43:47', '38.196.193.218', 'JONATHAV', 'Inicio de Sesión', '2025-06-07 01:43:47'),
	(236, '2025-06-06', '22:31:37', '38.196.193.218', 'JONATHAV', 'Cierre de Sesión', '2025-06-07 02:31:37'),
	(237, '2025-06-06', '22:31:49', '38.196.193.217', 'JONATHAV', 'Inicio de Sesión', '2025-06-07 02:31:49'),
	(238, '2025-06-06', '22:54:12', '38.196.193.220', 'JONATHAV', 'Inicio de Sesión', '2025-06-07 02:54:12'),
	(239, '2025-06-06', '23:02:52', '38.196.193.218', 'JONATHAV', 'Inicio de Sesión', '2025-06-07 03:02:52'),
	(240, '2025-06-06', '23:02:52', '38.196.193.218', 'JONATHAV', 'Inicio de Sesión', '2025-06-07 03:02:52'),
	(241, '2025-06-06', '23:12:15', '38.196.193.220', 'JONATHAV', 'Inicio de Sesión', '2025-06-07 03:12:15'),
	(242, '2025-06-06', '23:12:58', '38.196.193.220', 'JONATHAV', 'Inicio de Sesión', '2025-06-07 03:12:58'),
	(243, '2025-06-06', '23:21:50', '38.196.193.220', 'JONATHAV', 'Inicio de Sesión', '2025-06-07 03:21:50'),
	(244, '2025-06-06', '23:21:51', '38.196.193.220', 'JONATHAV', 'Inicio de Sesión', '2025-06-07 03:21:51'),
	(245, '2025-06-06', '23:22:41', '38.196.193.220', 'JONATHAV', 'Inicio de Sesión', '2025-06-07 03:22:41'),
	(246, '2025-06-06', '23:31:21', '38.196.193.220', 'JONATHAV', 'Inicio de Sesión', '2025-06-07 03:31:21'),
	(247, '2025-06-06', '23:31:22', '38.196.193.220', 'JONATHAV', 'Inicio de Sesión', '2025-06-07 03:31:22'),
	(248, '2025-06-06', '23:31:43', '::1', 'JONATHAV', 'Cambio de contraseña (sin encriptación)', '2025-06-07 03:31:44'),
	(249, '2025-06-06', '23:32:07', '38.196.193.220', 'JONATHAV', 'Inicio de Sesión', '2025-06-07 03:32:07'),
	(250, '2025-06-06', '23:32:53', '::1', 'JONATHAV', 'Cambio de contraseña (sin encriptación)', '2025-06-07 03:32:53'),
	(251, '2025-06-06', '23:35:46', '38.196.193.220', 'JONATHAV', 'Inicio de Sesión', '2025-06-07 03:35:46'),
	(252, '2025-06-06', '23:36:10', '38.196.193.220', 'JONATHAV', 'Cierre de Sesión', '2025-06-07 03:36:10'),
	(253, '2025-06-06', '23:48:44', '38.196.193.218', 'JONATHAV', 'Inicio de Sesión', '2025-06-07 03:48:44'),
	(254, '2025-06-07', '0:09:52', '38.196.193.218', 'JONATHAV', 'Inicio de Sesión', '2025-06-07 04:09:52'),
	(255, '2025-06-07', '0:09:53', '38.196.193.218', 'JONATHAV', 'Inicio de Sesión', '2025-06-07 04:09:53'),
	(256, '2025-06-07', '0:10:40', '38.196.193.218', 'JONATHAV', 'Cierre de Sesión', '2025-06-07 04:10:40'),
	(267, '2025-06-07', '0:21:57', '38.196.193.218', 'SARA', 'Inicio de Sesión', '2025-06-07 04:21:57'),
	(268, '2025-06-07', '0:22:41', '38.196.193.218', 'SARA', 'Cierre de Sesión', '2025-06-07 04:22:41'),
	(269, '2025-06-07', '0:22:44', '38.196.193.218', 'JONATHAV', 'Inicio de Sesión', '2025-06-07 04:22:44'),
	(270, '2025-06-07', '0:24:14', '38.196.193.218', 'JONATHAV', 'Cierre de Sesión', '2025-06-07 04:24:14'),
	(271, '2025-06-07', '0:24:39', '38.196.193.218', 'SARA', 'Inicio de Sesión', '2025-06-07 04:24:39'),
	(272, '2025-06-07', '0:30:08', '38.196.193.218', 'SARA', 'Inicio de Sesión', '2025-06-07 04:30:08'),
	(273, '2025-06-07', '0:41:10', '38.196.193.218', 'SARA', 'Inicio de Sesión', '2025-06-07 04:41:10'),
	(274, '2025-06-07', '0:50:23', '38.196.193.218', 'SARA', 'Cierre de Sesión', '2025-06-07 04:50:23'),
	(275, '2025-06-07', '0:50:25', '38.196.193.218', 'JONATHAV', 'Inicio de Sesión', '2025-06-07 04:50:25'),
	(276, '2025-06-07', '1:07:27', '38.196.193.217', 'JONATHAV', 'Inicio de Sesión', '2025-06-07 05:07:27'),
	(277, '2025-06-07', '1:29:24', '38.196.193.217', 'JONATHAV', 'Inicio de Sesión', '2025-06-07 05:29:24'),
	(278, '2025-06-07', '1:51:45', '38.196.193.218', 'JONATHAV', 'Inicio de Sesión', '2025-06-07 05:51:45');

-- Volcando estructura para tabla reu_db.calificaciones
CREATE TABLE IF NOT EXISTS `calificaciones` (
  `ID` int(5) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `Cedula_Estudiante` varchar(8) DEFAULT NULL,
  `Nombre_Estudiante` varchar(50) DEFAULT NULL COMMENT 'Concatenacion de Nombres y Apellidos',
  `Carrera` varchar(13) DEFAULT NULL,
  `Trayecto` int(1) DEFAULT NULL,
  `Sem/Trim` int(1) DEFAULT NULL,
  `Seccion` int(5) unsigned DEFAULT NULL,
  `Unidad_Curricular` varchar(13) DEFAULT NULL,
  `Cedula_Docente` varchar(8) DEFAULT NULL,
  `Nombre_Docente` varchar(50) DEFAULT NULL COMMENT 'Concatenacion de Nombres y Apellidos',
  `Estado` varchar(15) DEFAULT NULL COMMENT 'Asistente, Cargando Notas, Inasistente',
  `Calificacion_Numerica` int(2) DEFAULT NULL,
  `Calificacion_Cualitativa` varchar(9) DEFAULT NULL COMMENT 'Aprobado o Reprobado',
  `Periodo_Academico` char(6) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_calificaciones_estudiantes` (`Cedula_Estudiante`),
  KEY `FK_calificaciones_carreras` (`Carrera`),
  KEY `FK_calificaciones_secciones` (`Seccion`),
  KEY `FK_calificaciones_asignaturas` (`Unidad_Curricular`),
  KEY `FK_calificaciones_docentes` (`Cedula_Docente`),
  KEY `FK_calificaciones_periodo_academico` (`Periodo_Academico`),
  CONSTRAINT `FK_calificaciones_asignaturas` FOREIGN KEY (`Unidad_Curricular`) REFERENCES `asignaturas` (`Codigo_Asignatura`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_calificaciones_carreras` FOREIGN KEY (`Carrera`) REFERENCES `carreras` (`Codigo_Carrera`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_calificaciones_docentes` FOREIGN KEY (`Cedula_Docente`) REFERENCES `docentes` (`Cedula`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_calificaciones_estudiantes` FOREIGN KEY (`Cedula_Estudiante`) REFERENCES `estudiantes` (`Cedula`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_calificaciones_periodo_academico` FOREIGN KEY (`Periodo_Academico`) REFERENCES `periodo_academico` (`Periodo_Academico`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_calificaciones_secciones` FOREIGN KEY (`Seccion`) REFERENCES `secciones` (`Codigo_Seccion`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;

-- Volcando datos para la tabla reu_db.calificaciones: ~3 rows (aproximadamente)
REPLACE INTO `calificaciones` (`ID`, `Cedula_Estudiante`, `Nombre_Estudiante`, `Carrera`, `Trayecto`, `Sem/Trim`, `Seccion`, `Unidad_Curricular`, `Cedula_Docente`, `Nombre_Docente`, `Estado`, `Calificacion_Numerica`, `Calificacion_Cualitativa`, `Periodo_Academico`) VALUES
	(00013, '77777777', 'Bartolomeo Simpson', 'P-INF-2025', 1, 2, 30232, 'MAT-001', '0000000', 'PROFE PROFE', 'activo', 15, 'aprobado', '2026-1'),
	(00014, '77777777', 'Bartolomeo Simpsom', 'P-INF-2025', 2, 1, 30231, 'ING-001', '0000000', 'PROFE PROFE', 'activo', 12, 'aprobado', '2027-1'),
	(00015, '77777777', 'Bartolomeo Simpson', 'P-INF-2025', 2, 2, 30232, 'RED-001', '0000000', 'PROFE PROFE', 'activo', 17, 'apobado', '2028-1');

-- Volcando estructura para tabla reu_db.carreras
CREATE TABLE IF NOT EXISTS `carreras` (
  `Codigo_Carrera` varchar(13) NOT NULL COMMENT 'Primera letra de Pensum y un guion. Primeras 3 letras de cada palabra en mayusculas seguido del año de registro. Formato P-FFF-0000 o tambien P-FFF-FFF-0000',
  `Nombre_Carrera` varchar(25) NOT NULL,
  `Tipo` varchar(10) NOT NULL COMMENT 'Semestral, Trimestral',
  `Estado` varchar(8) NOT NULL COMMENT 'Activa o Inactiva',
  `Total_UC` int(3) NOT NULL COMMENT 'Formato 000',
  PRIMARY KEY (`Codigo_Carrera`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;

-- Volcando datos para la tabla reu_db.carreras: ~2 rows (aproximadamente)
REPLACE INTO `carreras` (`Codigo_Carrera`, `Nombre_Carrera`, `Tipo`, `Estado`, `Total_UC`) VALUES
	('P-ADM-2025', 'Administraciones', 'Trimestral', 'Activa', 33),
	('P-INF-2025', 'Informatica', 'Semestral', 'Activa', 25);

-- Volcando estructura para tabla reu_db.docentes
CREATE TABLE IF NOT EXISTS `docentes` (
  `Cedula` varchar(8) NOT NULL,
  `Usuario` varchar(20) NOT NULL,
  `Nombres` varchar(25) NOT NULL,
  `Apellidos` varchar(25) NOT NULL,
  `Estado_Docente` varchar(50) DEFAULT NULL COMMENT 'activo, inactivo',
  `Tipo` varchar(15) DEFAULT NULL COMMENT 'normal, virtual',
  `Telefono_1` varchar(11) NOT NULL,
  `Telefono_2` varchar(11) DEFAULT NULL,
  `Correo` varchar(50) NOT NULL,
  `Codigo_Carnet` varchar(25) DEFAULT NULL,
  `Fecha_Registro` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`Cedula`),
  KEY `FK_docentes_usuarios` (`Usuario`),
  CONSTRAINT `FK_docentes_usuarios` FOREIGN KEY (`Usuario`) REFERENCES `usuarios` (`ID_Usuario`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;

-- Volcando datos para la tabla reu_db.docentes: ~1 rows (aproximadamente)
REPLACE INTO `docentes` (`Cedula`, `Usuario`, `Nombres`, `Apellidos`, `Estado_Docente`, `Tipo`, `Telefono_1`, `Telefono_2`, `Correo`, `Codigo_Carnet`, `Fecha_Registro`) VALUES
	('0000000', 'PROFE', 'PROFE', 'PROFE', 'activo', 'virtual', '04120000000', NULL, 'JKJKJKJ', 'PROF-64787971', '2025-05-04 15:48:12');

-- Volcando estructura para tabla reu_db.docente_asignatura
CREATE TABLE IF NOT EXISTS `docente_asignatura` (
  `ID` int(5) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `Docente_Cedula` varchar(8) NOT NULL,
  `Docente_Nombre` varchar(50) NOT NULL,
  `Asignatura` varchar(13) NOT NULL,
  `Num_Alumnos` int(11) DEFAULT NULL,
  `Carrera` varchar(13) NOT NULL,
  `Pensum` varchar(25) NOT NULL DEFAULT '' COMMENT 'Primeras 3 letras de cada palabra en mayusculas seguido de un numero secuencial entero de 3 en este formato FFF000 o tambien FFF-FFF000',
  `Trayecto` int(1) NOT NULL,
  `Sem/Trim` int(1) NOT NULL,
  `Seccion` int(5) unsigned NOT NULL,
  `Clases_Semana` int(11) NOT NULL,
  `Estado` varchar(25) NOT NULL COMMENT 'Cargado Correctamente, Cargado Incorrectamente',
  `Periodo_Academico` char(6) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_docente_asignatura_docentes` (`Docente_Cedula`),
  KEY `FK_docente_asignatura_asignaturas` (`Asignatura`),
  KEY `FK_docente_asignatura_carreras` (`Carrera`),
  KEY `FK_docente_asignatura_secciones` (`Seccion`),
  KEY `FK_docente_asignatura_periodo_academico` (`Periodo_Academico`),
  KEY `FK_docente_asignatura_pensum` (`Pensum`),
  CONSTRAINT `FK_docente_asignatura_asignaturas` FOREIGN KEY (`Asignatura`) REFERENCES `asignaturas` (`Codigo_Asignatura`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_docente_asignatura_carreras` FOREIGN KEY (`Carrera`) REFERENCES `carreras` (`Codigo_Carrera`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_docente_asignatura_docentes` FOREIGN KEY (`Docente_Cedula`) REFERENCES `docentes` (`Cedula`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_docente_asignatura_pensum` FOREIGN KEY (`Pensum`) REFERENCES `pensum` (`Codigo_Pensum`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_docente_asignatura_periodo_academico` FOREIGN KEY (`Periodo_Academico`) REFERENCES `periodo_academico` (`Periodo_Academico`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_docente_asignatura_secciones` FOREIGN KEY (`Seccion`) REFERENCES `secciones` (`Codigo_Seccion`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci COMMENT='En esta tabla se asigna la asignatura que un docente registrado debera impartir en un periodo academico.';

-- Volcando datos para la tabla reu_db.docente_asignatura: ~0 rows (aproximadamente)

-- Volcando estructura para tabla reu_db.estudiantes
CREATE TABLE IF NOT EXISTS `estudiantes` (
  `Cedula` varchar(8) NOT NULL,
  `Usuario` varchar(20) NOT NULL,
  `Nombres` varchar(25) NOT NULL,
  `Apellidos` varchar(25) NOT NULL,
  `Carrera` varchar(13) DEFAULT NULL COMMENT 'Primeras 3 letras de cada palabra en mayusculas seguido de un numero secuencial entero de 3 en este formato FFF000 o tambien FFF-FFF000',
  `Estado_Pensum` varchar(17) DEFAULT 'pendiente' COMMENT 'Pensum Asignado, Pensum Pendiente',
  `Estado` varchar(15) DEFAULT 'nuevo-ingreso' COMMENT 'Regular, Nuevo Ingreso',
  `Telefono_1` varchar(11) NOT NULL,
  `Telefono_2` varchar(11) DEFAULT NULL,
  `Correo` varchar(50) NOT NULL,
  `Codigo_Carnet` varchar(25) NOT NULL,
  `Fecha_Registro` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`Cedula`),
  KEY `FK_estudiantes_carreras` (`Carrera`),
  KEY `FK_estudiantes_usuarios` (`Usuario`),
  CONSTRAINT `FK_estudiantes_carreras` FOREIGN KEY (`Carrera`) REFERENCES `carreras` (`Codigo_Carrera`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_estudiantes_usuarios` FOREIGN KEY (`Usuario`) REFERENCES `usuarios` (`ID_Usuario`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;

-- Volcando datos para la tabla reu_db.estudiantes: ~2 rows (aproximadamente)
REPLACE INTO `estudiantes` (`Cedula`, `Usuario`, `Nombres`, `Apellidos`, `Carrera`, `Estado_Pensum`, `Estado`, `Telefono_1`, `Telefono_2`, `Correo`, `Codigo_Carnet`, `Fecha_Registro`) VALUES
	('1234567', 'SARA', 'Sara', 'Saras', NULL, 'pendiente', 'nuevo-ingreso', '04210001123', NULL, 'correo', 'EST-57978477', '2025-06-07 04:20:29'),
	('77777777', 'ELBARTO', 'Bartolomeo', 'Simpson', 'P-INF-2025', 'pendiente', 'nuevo-ingreso', '04220000102', '21212121', 'HFJFFGHFFGHJF', 'EST-37464387', '2025-05-23 22:58:13');

-- Volcando estructura para tabla reu_db.estudiantes_asignatura
CREATE TABLE IF NOT EXISTS `estudiantes_asignatura` (
  `ID` int(5) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `Estudiante_Cedula` varchar(8) NOT NULL,
  `Estudiante_Nombre` varchar(50) NOT NULL,
  `Asignatura` varchar(13) NOT NULL DEFAULT 'Por cargar',
  `Seccion` int(5) unsigned NOT NULL,
  `Estado` varchar(25) NOT NULL DEFAULT 'cargando notas' COMMENT 'asistente, cargando notas, inasistente',
  `Periodo_Academico` char(6) NOT NULL,
  `Nota` int(5) DEFAULT NULL,
  `Nota_Definitiva` int(5) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_estudiantes_asignatura_estudiantes` (`Estudiante_Cedula`),
  KEY `FK_estudiantes_asignatura_asignaturas` (`Asignatura`),
  KEY `FK_estudiantes_asignatura_secciones` (`Seccion`),
  KEY `FK_estudiantes_asignatura_periodo_academico` (`Periodo_Academico`),
  CONSTRAINT `FK_estudiantes_asignatura_asignaturas` FOREIGN KEY (`Asignatura`) REFERENCES `asignaturas` (`Codigo_Asignatura`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_estudiantes_asignatura_estudiantes` FOREIGN KEY (`Estudiante_Cedula`) REFERENCES `estudiantes` (`Cedula`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_estudiantes_asignatura_periodo_academico` FOREIGN KEY (`Periodo_Academico`) REFERENCES `periodo_academico` (`Periodo_Academico`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_estudiantes_asignatura_secciones` FOREIGN KEY (`Seccion`) REFERENCES `secciones` (`Codigo_Seccion`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;

-- Volcando datos para la tabla reu_db.estudiantes_asignatura: ~3 rows (aproximadamente)
REPLACE INTO `estudiantes_asignatura` (`ID`, `Estudiante_Cedula`, `Estudiante_Nombre`, `Asignatura`, `Seccion`, `Estado`, `Periodo_Academico`, `Nota`, `Nota_Definitiva`) VALUES
	(00011, '77777777', 'Bartolomeo Simpson', 'MAT-001', 30232, 'asistente', '2026-1', 15, 20),
	(00012, '77777777', 'Bartolomeo Simpsom', 'ING-001', 30231, 'asistente', '2027-1', 12, 20),
	(00013, '77777777', 'Bartolome Simpson', 'RED-001', 30232, 'asistente', '2028-1', 17, 18);

-- Volcando estructura para tabla reu_db.estudiante_periodo_academico
CREATE TABLE IF NOT EXISTS `estudiante_periodo_academico` (
  `ID` int(5) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `Cedula_Estudiante` varchar(8) NOT NULL,
  `Estado` varchar(25) NOT NULL COMMENT 'Activo, Inactivo (Se añade automaticamente dependiendo del pago)',
  `Periodo_Academico` char(6) NOT NULL,
  `Carrera` varchar(13) NOT NULL,
  `Pago` varchar(16) NOT NULL COMMENT 'Pago Realizado, Pago Pendiente',
  `Monto_Pago` decimal(10,2) NOT NULL,
  `Moneda` varchar(4) NOT NULL DEFAULT 'Bs.' COMMENT 'Bs. o USD.',
  `Modalidad_Pago` varchar(50) NOT NULL COMMENT 'PagoMovil o Transferencia',
  `Entidad_Bancaria` varchar(50) NOT NULL,
  `Numero_Transferencia` int(11) NOT NULL DEFAULT 0,
  `Fecha_Pago` date NOT NULL,
  `Fecha_Registro` timestamp NOT NULL DEFAULT current_timestamp(),
  `Nivel_Pensum` varchar(50) NOT NULL DEFAULT '',
  `Turno` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `FK_estudiante_periodo_academico_estudiantes` (`Cedula_Estudiante`),
  KEY `FK_estudiante_periodo_academico_periodo_academico` (`Periodo_Academico`),
  KEY `FK_estudiante_periodo_academico_carreras` (`Carrera`),
  CONSTRAINT `FK_estudiante_periodo_academico_carreras` FOREIGN KEY (`Carrera`) REFERENCES `carreras` (`Codigo_Carrera`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_estudiante_periodo_academico_estudiantes` FOREIGN KEY (`Cedula_Estudiante`) REFERENCES `estudiantes` (`Cedula`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_estudiante_periodo_academico_periodo_academico` FOREIGN KEY (`Periodo_Academico`) REFERENCES `periodo_academico` (`Periodo_Academico`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;

-- Volcando datos para la tabla reu_db.estudiante_periodo_academico: ~1 rows (aproximadamente)
REPLACE INTO `estudiante_periodo_academico` (`ID`, `Cedula_Estudiante`, `Estado`, `Periodo_Academico`, `Carrera`, `Pago`, `Monto_Pago`, `Moneda`, `Modalidad_Pago`, `Entidad_Bancaria`, `Numero_Transferencia`, `Fecha_Pago`, `Fecha_Registro`, `Nivel_Pensum`, `Turno`) VALUES
	(00005, '1234567', 'activo', '2026-1', 'P-INF-2025', 'pendiente', 500.00, 'USD', 'Pago Movil', 'Banvo', 484848, '2025-06-07', '2025-06-10 04:00:00', 'Quinto Trimestre', 'nocturno');

-- Volcando estructura para tabla reu_db.horas
CREATE TABLE IF NOT EXISTS `horas` (
  `Desde` time NOT NULL,
  `Hasta` time NOT NULL,
  `Dias` set('Lunes','Martes','Miercoles','Jueves','Viernes','Sabado') NOT NULL,
  `Turno` varchar(50) DEFAULT NULL,
  `Carrera` varchar(13) DEFAULT NULL COMMENT 'Primeras 3 letras de cada palabra en mayusculas seguido de un numero secuencial entero de 3 en este formato FFF000 o tambien FFF-FFF000',
  `Pensum` varchar(50) NOT NULL,
  `Periodo_Academico` char(6) DEFAULT NULL,
  `Seccion` int(5) unsigned NOT NULL COMMENT 'Formato: 00000. Seccion (000) trayecto (0) y semestre (0)',
  `Nivel` varchar(50) NOT NULL DEFAULT '',
  `Asignatura` varchar(13) NOT NULL COMMENT 'Formato: FFF000 o FFFIII000 o FFF-FFFIII000',
  `Docente` varchar(50) NOT NULL,
  PRIMARY KEY (`Desde`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;

-- Volcando datos para la tabla reu_db.horas: ~2 rows (aproximadamente)
REPLACE INTO `horas` (`Desde`, `Hasta`, `Dias`, `Turno`, `Carrera`, `Pensum`, `Periodo_Academico`, `Seccion`, `Nivel`, `Asignatura`, `Docente`) VALUES
	('07:00:00', '12:00:00', 'Lunes,Miercoles,Viernes', 'Mañana', 'P-ADM-2025', 'P-ADM-2025', '2026-1', 30231, 'Primer Trimestre', 'RED-001', 'PROFE PROFE'),
	('12:00:00', '17:00:00', 'Lunes,Martes,Miercoles,Viernes', 'Tarde', 'P-ADM-2025', 'P-ADM-2025', '2026-1', 30231, 'Primer Trimestre', 'MAT-001', 'PROFE PROFE');

-- Volcando estructura para tabla reu_db.nivel_pensum
CREATE TABLE IF NOT EXISTS `nivel_pensum` (
  `Nombre_Nivel` varchar(50) NOT NULL DEFAULT '',
  `Orden_Nivel` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`Nombre_Nivel`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;

-- Volcando datos para la tabla reu_db.nivel_pensum: ~5 rows (aproximadamente)
REPLACE INTO `nivel_pensum` (`Nombre_Nivel`, `Orden_Nivel`) VALUES
	('Cuarto Trimestre', 4),
	('Primer Trimestre', 1),
	('Quinto Trimestre', 5),
	('Segundo Trimestre', 2),
	('Tercer Trimestre', 3);

-- Volcando estructura para tabla reu_db.pensum
CREATE TABLE IF NOT EXISTS `pensum` (
  `Nombre_Pensum` varchar(50) NOT NULL,
  `Num_Asignatura` varchar(11) NOT NULL,
  `Estado_Pensum` varchar(8) NOT NULL COMMENT 'Activo o Inactivo',
  `Codigo_Pensum` varchar(25) NOT NULL DEFAULT '' COMMENT 'Primeras 3 letras de cada palabra en mayusculas seguido de un numero secuencial entero de 3 en este formato FFF000 o tambien FFF-FFF000',
  PRIMARY KEY (`Codigo_Pensum`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;

-- Volcando datos para la tabla reu_db.pensum: ~1 rows (aproximadamente)
REPLACE INTO `pensum` (`Nombre_Pensum`, `Num_Asignatura`, `Estado_Pensum`, `Codigo_Pensum`) VALUES
	('Pensum en Administracion', '12', 'activo', 'P-ADM-2025');

-- Volcando estructura para tabla reu_db.periodo_academico
CREATE TABLE IF NOT EXISTS `periodo_academico` (
  `Periodo_Academico` char(6) NOT NULL COMMENT 'Año actual seguido de un guion y el semestre 1, o el 2 de esta forma: 0000-1',
  `Estado` varchar(8) NOT NULL DEFAULT 'Cursando' COMMENT 'Cursando o Cerrado. El valor se agrea automaticamente.',
  `Inicio` date NOT NULL,
  `Final` date NOT NULL,
  `Limite_UC` int(2) NOT NULL COMMENT 'Limite de creditos que los estudiantes pueden inscribir.',
  PRIMARY KEY (`Periodo_Academico`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;

-- Volcando datos para la tabla reu_db.periodo_academico: ~6 rows (aproximadamente)
REPLACE INTO `periodo_academico` (`Periodo_Academico`, `Estado`, `Inicio`, `Final`, `Limite_UC`) VALUES
	('2026-1', 'cursando', '2026-04-01', '2026-05-01', 25),
	('2027-1', 'cerrado', '2027-04-12', '2027-09-12', 25),
	('2028-1', 'cerrado', '2025-04-16', '2025-08-20', 25),
	('2029-2', 'cerrado', '2029-02-12', '2030-02-12', 25),
	('2030-1', 'cerrado', '2030-03-22', '2030-03-30', 25),
	('2040-1', 'cerrado', '2061-02-12', '2040-02-12', 30);

-- Volcando estructura para tabla reu_db.reinscripciones
CREATE TABLE IF NOT EXISTS `reinscripciones` (
  `ID` int(10) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `Cedula_Estudiante` varchar(50) NOT NULL DEFAULT '',
  `Carrera` varchar(50) NOT NULL DEFAULT '0',
  `Nivel_Pensum` varchar(50) NOT NULL DEFAULT '',
  `Turno` varchar(50) NOT NULL DEFAULT '',
  `Periodo_Academico` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;

-- Volcando datos para la tabla reu_db.reinscripciones: ~1 rows (aproximadamente)
REPLACE INTO `reinscripciones` (`ID`, `Cedula_Estudiante`, `Carrera`, `Nivel_Pensum`, `Turno`, `Periodo_Academico`) VALUES
	(0000000005, '1234567', 'P-INF-2025', 'Quinto Trimestre', 'nocturno', '2026-1');

-- Volcando estructura para tabla reu_db.secciones
CREATE TABLE IF NOT EXISTS `secciones` (
  `Codigo_Seccion` int(5) unsigned NOT NULL COMMENT 'Formato: 00000. Seccion (000) trayecto (0) y semestre (0)',
  PRIMARY KEY (`Codigo_Seccion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;

-- Volcando datos para la tabla reu_db.secciones: ~2 rows (aproximadamente)
REPLACE INTO `secciones` (`Codigo_Seccion`) VALUES
	(30231),
	(30232);

-- Volcando estructura para tabla reu_db.solicitudes_tutor_externo
CREATE TABLE IF NOT EXISTS `solicitudes_tutor_externo` (
  `ID` int(5) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `Cedula_Tutor` varchar(8) NOT NULL,
  `Nombre_Tutor` varchar(50) NOT NULL COMMENT 'Nombre Completo del Tutor',
  `Cedula_Solicitante` varchar(8) NOT NULL,
  `Nombre_Estudiante` varchar(50) NOT NULL,
  `Estado` varchar(25) NOT NULL DEFAULT 'Por Aprobar' COMMENT 'Por Aprobar, Aprobado, Rechazado',
  `Fecha_Solicitud` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`ID`),
  KEY `FK_solicitudes_tutor_externo_estudiantes` (`Cedula_Solicitante`),
  CONSTRAINT `FK_solicitudes_tutor_externo_estudiantes` FOREIGN KEY (`Cedula_Solicitante`) REFERENCES `estudiantes` (`Cedula`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;

-- Volcando datos para la tabla reu_db.solicitudes_tutor_externo: ~0 rows (aproximadamente)

-- Volcando estructura para tabla reu_db.solicitudes_tutor_interno
CREATE TABLE IF NOT EXISTS `solicitudes_tutor_interno` (
  `ID` int(5) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `Cedula_Docente` varchar(8) NOT NULL,
  `Nombre_Docente` varchar(50) NOT NULL,
  `Cedula_Solicitante` varchar(8) NOT NULL,
  `Nombre_Estudiante` varchar(50) NOT NULL,
  `Estado` varchar(25) NOT NULL DEFAULT 'Por Aprobar' COMMENT 'Por Aprobar, Aprobado, Rechazado',
  `Fecha_Solicitud` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`ID`),
  KEY `FK_solicitudes_tutor_interno_estudiantes` (`Cedula_Solicitante`),
  KEY `Docentee` (`Cedula_Docente`),
  CONSTRAINT `Docentee` FOREIGN KEY (`Cedula_Docente`) REFERENCES `docentes` (`Cedula`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_solicitudes_tutor_interno_estudiantes` FOREIGN KEY (`Cedula_Solicitante`) REFERENCES `estudiantes` (`Cedula`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;

-- Volcando datos para la tabla reu_db.solicitudes_tutor_interno: ~0 rows (aproximadamente)

-- Volcando estructura para tabla reu_db.trabajo_investigacion
CREATE TABLE IF NOT EXISTS `trabajo_investigacion` (
  `ID` int(5) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `Nombre_Investigacion` varchar(50) NOT NULL,
  `Carrera` varchar(13) NOT NULL,
  `Cedula_Estudiante` varchar(8) NOT NULL,
  `Nombre_Estudiante` varchar(50) NOT NULL,
  `Tutor_Cedula` varchar(8) NOT NULL,
  `Tutor_Nombre` varchar(50) NOT NULL,
  `Area_Interes` varchar(25) NOT NULL,
  `Periodo_Academico` char(6) NOT NULL,
  `Estado` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `Periodo Academico` (`Periodo_Academico`),
  KEY `Estudiante` (`Cedula_Estudiante`),
  KEY `Relacion carreras` (`Carrera`),
  CONSTRAINT `Estudiante` FOREIGN KEY (`Cedula_Estudiante`) REFERENCES `estudiantes` (`Cedula`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `Periodo Academico` FOREIGN KEY (`Periodo_Academico`) REFERENCES `periodo_academico` (`Periodo_Academico`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `Relacion carreras` FOREIGN KEY (`Carrera`) REFERENCES `carreras` (`Codigo_Carrera`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;

-- Volcando datos para la tabla reu_db.trabajo_investigacion: ~0 rows (aproximadamente)

-- Volcando estructura para tabla reu_db.usuarios
CREATE TABLE IF NOT EXISTS `usuarios` (
  `ID_Usuario` varchar(20) NOT NULL COMMENT 'Nombre de Usuario',
  `Password` varchar(300) NOT NULL,
  `Rol` varchar(20) NOT NULL COMMENT 'Administrador, Docente, Estudiante, Control_Estudios, Tutor_Externo, Administrativo',
  `Estado` varchar(13) NOT NULL COMMENT 'Habilitado o Deshabilitado',
  `Nombres` varchar(25) NOT NULL,
  `Apellidos` varchar(25) NOT NULL,
  `Genero` varchar(9) NOT NULL COMMENT 'Masculino o Femenino',
  `Residente` varchar(10) NOT NULL COMMENT 'Venezolano o Extranjero',
  `Cedula` varchar(8) NOT NULL COMMENT 'Numero de cedula sin signos',
  `Telefono_1` char(11) NOT NULL COMMENT 'Numero de contacto obliatorio',
  `Telefono_2` char(11) DEFAULT NULL COMMENT 'Opcional',
  `Correo` varchar(50) NOT NULL COMMENT 'Email obligatorio',
  `Direccion_Residencial` varchar(100) NOT NULL,
  `Codigo_Carnet` char(25) DEFAULT NULL COMMENT 'Se crea automaticamente',
  `Fecha_Registro` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'Se inserta automaticamente',
  PRIMARY KEY (`ID_Usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;

-- Volcando datos para la tabla reu_db.usuarios: ~7 rows (aproximadamente)
REPLACE INTO `usuarios` (`ID_Usuario`, `Password`, `Rol`, `Estado`, `Nombres`, `Apellidos`, `Genero`, `Residente`, `Cedula`, `Telefono_1`, `Telefono_2`, `Correo`, `Direccion_Residencial`, `Codigo_Carnet`, `Fecha_Registro`) VALUES
	('DIRIARTE', 'ingdangelo2025', 'Administrador', 'Habilitado', 'Dangelo', 'Iriarte', '', '', '00000000', '00000000000', NULL, 'dangelo.iriarte@gmail.com', 'Caracas', NULL, '2025-02-28 06:28:38'),
	('ELBARTO', 'sjt6gwWd', 'Estudiante', 'Habilitado', 'Bartolomeo', 'Simpson', 'Masculino', 'ELBARTO', '77777777', '04220000102', '21212121', 'HFJFFGHFFGHJF', 'Springfield', 'EST-37464387', '2025-05-23 22:58:13'),
	('GENESYSP718', 'inggenesis2025', 'Administrador', 'Habilitado', 'Genesis', 'Barrios', '', '', '00000000', '00000000000', NULL, 'genesysp718@gmail.com', 'Caracas', NULL, '2025-02-28 06:37:58'),
	('JONATHAV', 'ingjonathan2025', 'Administrador', 'Habilitado', 'Jonathan', 'Vargas', 'Masculino', 'Venezilano', '00000000', '04268216907', NULL, 'jonathanalexvargas@gmail.com', 'Caracas', NULL, '2025-02-28 06:19:09'),
	('JUNIOR09', 'ingjunior2025', 'Administrador', 'Habilitado', 'Junior', 'Araque', 'Masculono', 'Venezolano', '00000000', '00000000000', NULL, 'junioraraque09@gmail.com', 'Caracas', NULL, '2025-02-28 06:28:38'),
	('PROFE', '50cuWjwL', 'Docente', 'Habilitado', 'PROFE', 'PROFE', 'Masculino', 'Venezolano', '0000000', '04120000000', '', 'JKJKJKJ', 'hjjhhj', 'PROF-64787971', '2025-05-04 15:48:12'),
	('SARA', 'BBCKr92b', 'Estudiante', 'Habilitado', 'Sara', 'Saras', 'Femenino', 'Venezolana', '1234567', '04210001123', NULL, 'correo@email.com', 'Caracas', 'EST-57978477', '2025-06-07 04:20:13');

-- Volcando estructura para disparador reu_db.after_reinscripciones_insert
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `after_reinscripciones_insert` AFTER INSERT ON `reinscripciones` FOR EACH ROW BEGIN
    -- Actualizar los datos en estudiantes_periodo_academico cuando coincidan cédula y período académico
    UPDATE estudiante_periodo_academico
    SET 
        Carrera = NEW.Carrera,
        Nivel_Pensum = NEW.Nivel_Pensum,
        Turno = NEW.Turno
    WHERE 
        Cedula_Estudiante = NEW.Cedula_Estudiante 
        AND Periodo_Academico = NEW.Periodo_Academico;
END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;

-- Volcando estructura para disparador reu_db.calificaciones_after_insert
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `calificaciones_after_insert` AFTER INSERT ON `calificaciones` FOR EACH ROW BEGIN
    INSERT INTO estudiantes_asignatura (Estudiante_Cedula, Estudiante_Nombre, Seccion, Periodo_Academico, Nota, Asignatura)
    VALUES (NEW.Cedula_Estudiante, NEW.Nombre_Estudiante, NEW.Seccion, NEW.Periodo_Academico, NEW.Calificacion_Numerica, NEW.Unidad_Curricular);
END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;

-- Volcando estructura para disparador reu_db.codigo_carnet
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `codigo_carnet` BEFORE INSERT ON `usuarios` FOR EACH ROW BEGIN
  DECLARE nuevo_codigo VARCHAR(25);
  DECLARE nueva_password VARCHAR(8);
  DECLARE caracteres VARCHAR(62);
  DECLARE i INT;
  DECLARE numero_aleatorio INT;
  
  -- Generar contraseña aleatoria alfanumérica de 8 caracteres (código existente)
  SET caracteres = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  SET nueva_password = '';
  SET i = 0;
  
  -- Generar 8 caracteres aleatorios (código existente)
  WHILE i < 8 DO
    SET nueva_password = CONCAT(nueva_password, SUBSTRING(caracteres, FLOOR(1 + RAND() * 62), 1));
    SET i = i + 1;
  END WHILE;
  
  -- Verificar que la contraseña no exista (muy improbable pero por seguridad) (código existente)
  WHILE EXISTS (SELECT 1 FROM usuarios WHERE Password = nueva_password) DO
    SET nueva_password = '';
    SET i = 0;
    WHILE i < 8 DO
      SET nueva_password = CONCAT(nueva_password, SUBSTRING(caracteres, FLOOR(1 + RAND() * 62), 1));
      SET i = i + 1;
    END WHILE;
  END WHILE;
  
  -- Asignar la nueva contraseña (código existente)
  SET NEW.Password = nueva_password;
  
  -- Código modificado para generar códigos de carnet de 8 dígitos
  IF NEW.Rol = 'Estudiante' THEN
    -- Generar número de 8 dígitos aleatorio
    SET numero_aleatorio = FLOOR(10000000 + RAND() * 90000000);
    SET nuevo_codigo = CONCAT('EST-', numero_aleatorio);
    
    -- Verificar que el código no exista
    WHILE EXISTS (SELECT 1 FROM usuarios WHERE Codigo_Carnet = nuevo_codigo) DO
      SET numero_aleatorio = FLOOR(10000000 + RAND() * 90000000);
      SET nuevo_codigo = CONCAT('EST-', numero_aleatorio);
    END WHILE;
    
    SET NEW.Codigo_Carnet = nuevo_codigo;
    
  ELSEIF NEW.Rol = 'Docente' THEN
    -- Generar número de 8 dígitos aleatorio
    SET numero_aleatorio = FLOOR(10000000 + RAND() * 90000000);
    SET nuevo_codigo = CONCAT('DTE-', numero_aleatorio);
    
    -- Verificar que el código no exista
    WHILE EXISTS (SELECT 1 FROM usuarios WHERE Codigo_Carnet = nuevo_codigo) DO
      SET numero_aleatorio = FLOOR(10000000 + RAND() * 90000000);
      SET nuevo_codigo = CONCAT('DTE-', numero_aleatorio);
    END WHILE;
    
    SET NEW.Codigo_Carnet = nuevo_codigo;
    
  ELSE
    SET NEW.Codigo_Carnet = NULL; -- Dejar vacío si no es Estudiante ni Docente
  END IF;
  
END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;

-- Volcando estructura para disparador reu_db.registro_estudiante_profesor
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `registro_estudiante_profesor` AFTER INSERT ON `usuarios` FOR EACH ROW BEGIN
IF NEW.Rol = 'Estudiante' THEN
INSERT INTO estudiantes (Usuario, Cedula, Nombres, Apellidos, Codigo_Carnet, Telefono_1, Telefono_2, Correo)
VALUES (NEW.ID_Usuario, NEW.Cedula, NEW.Nombres, NEW.Apellidos, NEW.Codigo_Carnet, NEW.Telefono_1, NEW.Telefono_2,  NEW.Correo);
ELSEIF NEW.Rol = 'Docente' THEN
INSERT INTO docentes (Usuario, Cedula, Nombres, Apellidos, Telefono_1, Telefono_2, Correo, Codigo_Carnet)
VALUES (NEW.ID_Usuario, NEW.Cedula, NEW.Nombres, NEW.Apellidos,  NEW.Telefono_1,  NEW.Telefono_2,  NEW.Correo, NEW.Codigo_Carnet);
END IF;
END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
