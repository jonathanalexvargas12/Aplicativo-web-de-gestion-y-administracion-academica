function inicializarPaginacionTutoria() {
    const tabla = document.querySelector('.tabla-tutorias tbody');

    if (!tabla) {
        console.error("No se encontró la tabla con la clase .tabla-tutorias o su tbody.");
        return;
    }

    const filas = tabla.querySelectorAll('tr');
    const numFilasPorPagina = 5;
    let paginaActual = 1;
    let numPaginas = Math.ceil(filas.length / numFilasPorPagina);

    const numerosPaginaDiv = document.querySelector('.numeros-pagina-tutoria');
    const infoPaginacionSpan = document.querySelector('.info-paginacion-tutoria');
    const btnAnterior = document.querySelector('.pagina-anterior-tutoria');
    const btnSiguiente = document.querySelector('.pagina-siguiente-tutoria');

    if (!numerosPaginaDiv || !infoPaginacionSpan || !btnAnterior || !btnSiguiente) {
        console.error("No se encontraron los elementos de paginación.");
        return;
    }

    function mostrarPagina(numPagina) {
        paginaActual = numPagina;
        const inicio = (numPagina - 1) * numFilasPorPagina;
        const fin = inicio + numFilasPorPagina;

        for (let i = 0; i < filas.length; i++) {
            filas[i].style.display = 'none';
            if (i >= inicio && i < fin) {
                filas[i].style.display = '';
            }
        }

        actualizarNumerosPagina();
        actualizarInfoPaginacion();
    }

    function actualizarNumerosPagina() {
        numerosPaginaDiv.innerHTML = '';

        for (let i = 1; i <= numPaginas; i++) {
            const btnNumero = document.createElement('button');
            btnNumero.classList.add('numero-pagina-tutoria');
            btnNumero.textContent = i;
            if (i === paginaActual) {
                btnNumero.classList.add('activo');
            }
            btnNumero.addEventListener('click', () => mostrarPagina(i));
            numerosPaginaDiv.appendChild(btnNumero);
        }
    }

    function actualizarInfoPaginacion() {
        const inicio = (paginaActual - 1) * numFilasPorPagina + 1;
        const fin = Math.min(paginaActual * numFilasPorPagina, filas.length);
        infoPaginacionSpan.textContent = `${inicio}-${fin} de ${filas.length}`;

        btnAnterior.disabled = paginaActual === 1;
        btnSiguiente.disabled = paginaActual === numPaginas;
    }

    btnAnterior.addEventListener('click', () => {
        if (paginaActual > 1) {
            mostrarPagina(paginaActual - 1);
        }
    });

    btnSiguiente.addEventListener('click', () => {
        if (paginaActual < numPaginas) {
            mostrarPagina(paginaActual + 1);
        }
    });

    mostrarPagina(1);
}

document.addEventListener('DOMContentLoaded', inicializarPaginacionTutoria);