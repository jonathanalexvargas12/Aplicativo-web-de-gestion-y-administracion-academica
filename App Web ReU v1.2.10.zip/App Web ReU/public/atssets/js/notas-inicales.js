import GenericTable from './genericTable.js';

document.addEventListener('DOMContentLoaded', () => {
    // Instanciar la tabla genérica para notas iniciales
    const tablaNotas = new GenericTable(
        'calificaciones',
        'tabla-notas',
        ['ID', 'Periodo_Academico', 'Cedula_Estudiante', 'Nombre_Estudiante', 'Unidad_Curricular', 
         'Calificacion_Numerica', 'Calificacion_Cualitativa', 'Cedula_Docente', 'Nombre_Docente'],
        ['Periodo_Academico', 'Nombre_Estudiante', 'Unidad_Curricular', 'Calificacion_Numerica', 'Calificacion_Cualitativa', 'Nombre_Docente']
    );

    // Función para obtener el token JWT
    const getToken = () => localStorage.getItem('token');

    // Variables para la paginación y búsqueda
    const buscarInput = document.querySelector('.buscar-input-notas');
    const botonBuscar = document.querySelector('.btn-buscar-notas');
    const btnReajustar = document.querySelector('.btn-reajustar-notas');
    const rowsPerPage = 5;
    let currentPage = 1;
    let totalRows = 0;
    let totalPages = 0;
    let filasOriginales = [];

    // Función para formatear los datos de la tabla
    tablaNotas.formatearDatos = (data) => {
        return data.map(item => ({
            ...item,
            Nombre_Estudiante: `${item.Nombre_Estudiante} (${item.Cedula_Estudiante})`,
            Unidad_Curricular: item.Unidad_Curricular,
            Nombre_Docente: `${item.Nombre_Docente} (${item.Cedula_Docente})`
        }));
    };

    // Función para clonar las filas originales
    const clonarFilasOriginales = () => {
        const filas = document.querySelectorAll('#tabla-notas tbody tr');
        filasOriginales = Array.from(filas).map(fila => fila.cloneNode(true));
    };

    // Función para filtrar la tabla
    const filtrarTabla = () => {
        const textoBusqueda = buscarInput.value.toLowerCase();
        const tbody = document.querySelector('#tabla-notas tbody');
        tbody.innerHTML = '';

        filasOriginales.forEach(fila => {
            const periodo = fila.cells[0].textContent.toLowerCase();
            const estudiante = fila.cells[1].textContent.toLowerCase();
            const asignatura = fila.cells[2].textContent.toLowerCase();
            const calificacion = fila.cells[3].textContent.toLowerCase();
            const cualitativa = fila.cells[4].textContent.toLowerCase();
            const docente = fila.cells[5].textContent.toLowerCase();

            if (textoBusqueda === '' || 
                periodo.includes(textoBusqueda) || 
                estudiante.includes(textoBusqueda) || 
                asignatura.includes(textoBusqueda) || 
                calificacion.includes(textoBusqueda) || 
                cualitativa.includes(textoBusqueda) || 
                docente.includes(textoBusqueda)) {
                tbody.appendChild(fila.cloneNode(true));
            }
        });

        tablaNotas.asignarEventosEliminar();
        actualizarPaginacion();
    };

    // Función para mostrar las filas de la página actual
    const displayRows = (page) => {
        const start = (page - 1) * rowsPerPage;
        const end = start + rowsPerPage;
        const filas = document.querySelectorAll('#tabla-notas tbody tr');

        filas.forEach((fila, index) => {
            fila.style.display = (index >= start && index < end) ? '' : 'none';
        });

        document.querySelector('.info-paginacion-notas').textContent = 
            `${start + 1}-${Math.min(end, totalRows)} de ${totalRows}`;
        
        tablaNotas.asignarEventosEliminar();
    };

    // Función para actualizar los botones de paginación
    const updatePaginationButtons = () => {
        const prevButton = document.querySelector('.pagina-anterior-notas');
        const nextButton = document.querySelector('.pagina-siguiente-notas');
        const pageButtonsContainer = document.querySelector('.numeros-pagina-notas');

        prevButton.disabled = currentPage === 1;
        nextButton.disabled = currentPage === totalPages;

        pageButtonsContainer.innerHTML = '';

        for (let i = 1; i <= totalPages; i++) {
            const button = document.createElement('button');
            button.classList.add('numero-pagina-notas');
            if (i === currentPage) {
                button.classList.add('activo');
            }
            button.textContent = i;
            button.addEventListener('click', () => {
                currentPage = i;
                displayRows(currentPage);
                updatePaginationButtons();
            });
            pageButtonsContainer.appendChild(button);
        }
    };

    // Función para actualizar la paginación
    const actualizarPaginacion = () => {
        const filas = document.querySelectorAll('#tabla-notas tbody tr');
        totalRows = filas.length;
        totalPages = Math.ceil(totalRows / rowsPerPage);
        currentPage = Math.min(currentPage, totalPages);
        displayRows(currentPage);
        updatePaginationButtons();
    };

    // Función para cargar select con manejo de errores
    async function cargarSelect(url, selectId, valueField, textField, formatter = null) {
        try {
            const token = getToken();
            if (!token) throw new Error('Token no encontrado');

            const response = await fetch(url, {
                headers: { 'Authorization': `Bearer ${token}` }
            });

            if (!response.ok) throw new Error('Error en la respuesta');

            const data = await response.json();
            const select = document.getElementById(selectId);
            
            // Limpiar select manteniendo la primera opción
            select.innerHTML = '<option value="" disabled selected>Seleccione una opción</option>';

            if (!data || data.length === 0) {
                const option = document.createElement('option');
                option.value = '';
                option.textContent = 'No se encontraron datos';
                option.disabled = true;
                select.appendChild(option);
                return;
            }

            // Agregar nuevas opciones
            data.forEach(item => {
                if (item[valueField] && (item[textField] || item[valueField])) {
                    const option = document.createElement('option');
                    option.value = item[valueField];
                    option.textContent = formatter ? formatter(item) : (item[textField] || item[valueField]);
                    select.appendChild(option);
                }
            });

        } catch (error) {
            console.error(`Error cargando ${selectId}:`, error);
            const select = document.getElementById(selectId);
            select.innerHTML = '<option value="" disabled selected>Error cargando datos</option>';
        }
    }

    // Función para cargar estudiantes (nombre + apellido + cédula)
    async function cargarEstudiantes() {
        await cargarSelect(
            '/api/estudiantes',
            'agregar-estudiante',
            'Cedula',
            'Nombres',
            (est) => `${est.Nombres} ${est.Apellidos} (${est.Cedula})`
        );
    }

    // Función para cargar asignaturas (nombre + código)
    async function cargarAsignaturas() {
        await cargarSelect(
            '/api/asignaturas',
            'agregar-asignatura',
            'Codigo_Asignatura',
            'Nombre_Asignatura',
            (asig) => `${asig.Nombre_Asignatura} (${asig.Codigo_Asignatura})`
        );
    }

    // Función para cargar docentes (nombre + apellido + cédula)
    async function cargarDocentes() {
        await cargarSelect(
            '/api/docentes',
            'agregar-usuario-responsable',
            'Cedula',
            'Nombres',
            (doc) => `${doc.Nombres} ${doc.Apellidos} (${doc.Cedula})`
        );
    }

    // Cargar datos para modal de agregar
    async function cargarDatosAgregar() {
        await Promise.all([
            cargarSelect('/api/periodo_academico', 'agregar-periodo', 'Periodo_Academico', 'Periodo_Academico'),
            cargarEstudiantes(),
            cargarAsignaturas(),
            cargarDocentes()
        ]);
    }

    // Manejador para eliminar
    tablaNotas.onEliminar = (id) => {
        const modal = document.getElementById('eliminarNotaModal');
        modal.style.display = 'block';

        document.getElementById('btn-aceptar-eliminar-nota').onclick = async () => {
            try {
                const token = getToken();
                if (!token) throw new Error('No se encontró el token JWT');

                const response = await fetch(`/api/calificaciones/${id}`, {
                    method: 'DELETE',
                    headers: {
                        'Authorization': `Bearer ${token}`
                    },
                });

                if (!response.ok) throw new Error('Error al eliminar el registro');
                modal.style.display = 'none';
                tablaNotas.cargarDatos().then(() => {
                    clonarFilasOriginales();
                    actualizarPaginacion();
                });
            } catch (error) {
                console.error('Error:', error);
            }
        };

        const eliminarClose = document.querySelector('.eliminar-close');
        if (eliminarClose) {
            eliminarClose.addEventListener('click', () => {
                modal.style.display = 'none';
            });
        }

        const cancelarEliminar = document.getElementById('btn-cancelar-eliminar-nota');
        if (cancelarEliminar) {
            cancelarEliminar.addEventListener('click', () => {
                modal.style.display = 'none';
            });
        }
    };

    // Agregar nueva nota - Versión mejorada
    const agregarForm = document.getElementById('agregar-nota-modal-form');
    const agregarModal = document.getElementById('agregarNotaModal');

    document.getElementById('btn-agregar-nota').addEventListener('click', async () => {
        await cargarDatosAgregar();
        agregarModal.style.display = 'block';
    });

    agregarForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        try {
            const token = getToken();
            if (!token) {
                alert('No se encontró el token de autenticación. Por favor, inicie sesión nuevamente.');
                return;
            }

            // Validar campos requeridos
            const calificacionNumerica = parseFloat(document.getElementById('agregar-calificacion').value);
            const calificacionCualitativa = document.getElementById('agregar-calificacion-cualitativa').value;
            
            if (isNaN(calificacionNumerica)) {
                throw new Error('La calificación numérica debe ser un valor válido');
            }

            // Obtener datos de los selects
            const periodoSelect = document.getElementById('agregar-periodo');
            const estudianteSelect = document.getElementById('agregar-estudiante');
            const asignaturaSelect = document.getElementById('agregar-asignatura');
            const docenteSelect = document.getElementById('agregar-usuario-responsable');
            
            // Validar que todos los campos estén seleccionados
            if (!periodoSelect.value || !estudianteSelect.value || !asignaturaSelect.value || !docenteSelect.value) {
                throw new Error('Todos los campos son obligatorios');
            }

            // Preparar datos para enviar al servidor
            const datosCalificacion = {
                Periodo_Academico: periodoSelect.value,
                Cedula_Estudiante: estudianteSelect.value,
                Nombre_Estudiante: estudianteSelect.options[estudianteSelect.selectedIndex].text.split(' (')[0],
                Unidad_Curricular: asignaturaSelect.options[asignaturaSelect.selectedIndex].text,
                Calificacion_Numerica: calificacionNumerica,
                Calificacion_Cualitativa: calificacionCualitativa,
                Cedula_Docente: docenteSelect.value,
                Nombre_Docente: docenteSelect.options[docenteSelect.selectedIndex].text.split(' (')[0],
                Estado: 'Activo'
            };

            console.log('Datos a enviar:', datosCalificacion); // Para depuración

            const response = await fetch('/api/calificaciones', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify(datosCalificacion)
            });

            if (!response.ok) {
                let errorMsg = 'Error al agregar la nota';
                try {
                    const errorData = await response.json();
                    errorMsg = errorData.message || errorData.error || errorMsg;
                    
                    // Manejar errores específicos conocidos
                    if (errorData.details) {
                        errorMsg += `: ${errorData.details.join(', ')}`;
                    }
                } catch (e) {
                    console.error('Error al parsear respuesta de error:', e);
                }
                throw new Error(errorMsg);
            }

            // Mostrar feedback al usuario
            alert('Nota agregada correctamente');
            
            // Cerrar modal y resetear formulario
            agregarModal.style.display = 'none';
            agregarForm.reset();

            // Actualizar la tabla
            await tablaNotas.cargarDatos();
            clonarFilasOriginales();
            actualizarPaginacion();

        } catch (error) {
            console.error('Error al agregar nota:', error);
            alert(`Error: ${error.message}\n\nPor favor, verifique los datos e intente nuevamente.`);
            
            // Mostrar detalles adicionales en consola para depuración
            if (error.response) {
                console.error('Respuesta del servidor:', error.response);
            }
        }
    });
    
    // Cerrar modal de agregar
    const agregarClose = document.querySelector('.agregar-close');
    agregarClose.addEventListener('click', () => {
        agregarModal.style.display = 'none';
        agregarForm.reset();
    });

    const cancelarAgregar = document.getElementById('cancelar-agregar-nota-modal');
    if (cancelarAgregar) {
        cancelarAgregar.addEventListener('click', () => {
            agregarModal.style.display = 'none';
            agregarForm.reset();
        });
    }

    // Eventos de búsqueda y reajuste
    botonBuscar.addEventListener('click', filtrarTabla);
    
    btnReajustar.addEventListener('click', () => {
        buscarInput.value = '';
        const tbody = document.querySelector('#tabla-notas tbody');
        tbody.innerHTML = '';
        filasOriginales.forEach(fila => tbody.appendChild(fila.cloneNode(true)));
        tablaNotas.asignarEventosEliminar();
        actualizarPaginacion();
    });

    // Evento para búsqueda al presionar Enter
    buscarInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            filtrarTabla();
        }
    });

    // Eventos de paginación
    document.querySelector('.pagina-anterior-notas').addEventListener('click', () => {
        if (currentPage > 1) {
            currentPage--;
            displayRows(currentPage);
            updatePaginationButtons();
        }
    });

    document.querySelector('.pagina-siguiente-notas').addEventListener('click', () => {
        if (currentPage < totalPages) {
            currentPage++;
            displayRows(currentPage);
            updatePaginationButtons();
        }
    });

    // Inicialización
    tablaNotas.cargarDatos().then(() => {
        clonarFilasOriginales();
        actualizarPaginacion();
    }); 
});