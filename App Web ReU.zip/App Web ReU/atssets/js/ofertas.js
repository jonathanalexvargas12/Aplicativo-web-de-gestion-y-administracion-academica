// Para que se desplieguen los filtros de busqueda

const btnFiltrarOfertas = document.getElementById('btn-filtrar-ofertas');
const filtrosBusquedaOfertas = document.getElementById('filtros-busqueda-ofertas');

btnFiltrarOfertas.addEventListener('click', () => {
    filtrosBusquedaOfertas.classList.toggle('mostrar');
});