// Para que se desplieguen los filtros
const btnFiltrarInvestigaciones = document.getElementById('btn-filtrar-investigaciones');
const filtrosBusquedaInvestigaciones = document.getElementById('filtros-busqueda-investigaciones');

btnFiltrarInvestigaciones.addEventListener('click', () => {
    filtrosBusquedaInvestigaciones.classList.toggle('mostrar');
});
 
// Filtro de busqueda
function filtrarInvestigaciones() {
    const buscarInput = document.getElementById('buscar-input-investigaciones').value.toLowerCase();
    const estatusSelect = document.getElementById('estatus-select-investigaciones').value.toLowerCase();
    const areaSelect = document.getElementById('area-select-investigaciones').value.toLowerCase();
    const periodoSelect = document.getElementById('periodo-aprobacion-select-investigaciones').value.toLowerCase();
    const lineaSelect = document.getElementById('linea-investigacion-select-investigaciones').value.toLowerCase();
    
    const filas = document.querySelectorAll('#tabla-investigaciones tbody tr');
    
    filas.forEach(fila => {
        const cells = fila.getElementsByTagName('td');
        const tutor = cells[1].innerText.toLowerCase();
        const estudiante = cells[2].innerText.toLowerCase();
        const periodo = cells[3].innerText.toLowerCase();
        const estatus = cells[4].innerText.toLowerCase();
        const area = estudiante.split('(')[1]?.split(')')[0].toLowerCase(); // Extrae el área de interés del texto
        
        const coincideConBusqueda = tutor.includes(buscarInput) || estudiante.includes(buscarInput);
        const coincideConEstatus = estatus.includes(estatusSelect) || estatusSelect === '';
        const coincideConArea = area.includes(areaSelect) || areaSelect === '';
        const coincideConPeriodo = periodo.includes(periodoSelect) || periodoSelect === '';
        const coincideConLinea = estudiante.includes(lineaSelect) || lineaSelect === '';

        if (coincideConBusqueda && coincideConEstatus && coincideConArea && coincideConPeriodo && coincideConLinea) {
            fila.style.display = '';
        } else {
            fila.style.display = 'none';
        }
    });
}

// Función para reajustar los filtros
function reajustarFiltros() {
    document.getElementById('buscar-input-investigaciones').value = '';
    document.getElementById('estatus-select-investigaciones').value = '';
    document.getElementById('area-select-investigaciones').value = '';
    document.getElementById('periodo-aprobacion-select-investigaciones').value = '';
    document.getElementById('linea-investigacion-select-investigaciones').value = '';
    
    // Llamar a la función de filtrado para aplicar los filtros vacíos
    filtrarInvestigaciones();
}

// Evento para el botón de búsqueda
document.querySelector('.btn-buscar-investigaciones').addEventListener('click', filtrarInvestigaciones);

// Evento para el botón de reajustar filtros
document.getElementById('btn-reajustar-investigaciones').addEventListener('click', reajustarFiltros);


// Paginacion

let paginaActual = 1;
const filasPorPagina = 5;

function mostrarPagina() {
    const filas = document.querySelectorAll('#tabla-investigaciones tbody tr');
    const totalPaginas = Math.ceil(filas.length / filasPorPagina);
    
    // Calcular las filas que se deben mostrar
    const inicio = (paginaActual - 1) * filasPorPagina;
    const fin = paginaActual * filasPorPagina;
    
    // Mostrar solo las filas correspondientes a la página actual
    filas.forEach((fila, index) => {
        if (index >= inicio && index < fin) {
            fila.style.display = '';
        } else {
            fila.style.display = 'none';
        }
    });

    // Actualizar la información de la paginación
    const infoPaginacion = document.querySelector('.info-paginacion-investigaciones');
    infoPaginacion.textContent = `${inicio + 1}-${Math.min(fin, filas.length)} de ${filas.length}`;
    
    // Actualizar la clase activa en los botones de página
    const botonesPagina = document.querySelectorAll('.numero-pagina-investigaciones');
    botonesPagina.forEach((boton, index) => {
        if (index === paginaActual - 1) {
            boton.classList.add('activo');
        } else {
            boton.classList.remove('activo');
        }
    });

    // Mostrar u ocultar los botones de "Anterior" y "Siguiente"
    const btnPaginaAnterior = document.querySelector('.pagina-anterior-investigaciones');
    const btnPaginaSiguiente = document.querySelector('.pagina-siguiente-investigaciones');

    btnPaginaAnterior.style.display = paginaActual === 1 ? 'none' : '';
    btnPaginaSiguiente.style.display = paginaActual === totalPaginas ? 'none' : '';
}

// Función para ir a la página siguiente
function paginaSiguiente() {
    const filas = document.querySelectorAll('#tabla-investigaciones tbody tr');
    const totalPaginas = Math.ceil(filas.length / filasPorPagina);
    if (paginaActual < totalPaginas) {
        paginaActual++;
        mostrarPagina();
    }
}

// Función para ir a la página anterior
function paginaAnterior() {
    if (paginaActual > 1) {
        paginaActual--;
        mostrarPagina();
    }
}

// Función para ir a una página específica
function irAPagina(numeroPagina) {
    paginaActual = numeroPagina;
    mostrarPagina();
}

// Evento para los botones de paginación
document.querySelector('.pagina-anterior-investigaciones').addEventListener('click', paginaAnterior);
document.querySelector('.pagina-siguiente-investigaciones').addEventListener('click', paginaSiguiente);

// Eventos para los botones de páginas numeradas
document.querySelectorAll('.numero-pagina-investigaciones').forEach((boton, index) => {
    boton.addEventListener('click', () => irAPagina(index + 1));
});

// Inicializar la paginación al cargar la página
mostrarPagina();