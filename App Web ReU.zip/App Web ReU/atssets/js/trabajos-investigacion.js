// Para que se desplieguen los filtros
const btnFiltrarInvestigaciones = document.getElementById('btn-filtrar-investigaciones');
const filtrosBusquedaInvestigaciones = document.getElementById('filtros-busqueda-investigaciones');

btnFiltrarInvestigaciones.addEventListener('click', () => {
    filtrosBusquedaInvestigaciones.classList.toggle('mostrar');
});
 
// Filtro de busqueda
function filtrarInvestigaciones() {
    const buscarInput = document.getElementById('buscar-input-investigaciones').value.toLowerCase();
    const estatusSelect = document.getElementById('estatus-select-investigaciones').value.toLowerCase();
    const areaSelect = document.getElementById('area-select-investigaciones').value.toLowerCase();
    const periodoSelect = document.getElementById('periodo-aprobacion-select-investigaciones').value.toLowerCase();
    const lineaSelect = document.getElementById('linea-investigacion-select-investigaciones').value.toLowerCase();
    
    const filas = document.querySelectorAll('#tabla-investigaciones tbody tr');
    
    filas.forEach(fila => {
        const cells = fila.getElementsByTagName('td');
        const tutor = cells[1].innerText.toLowerCase();
        const estudiante = cells[2].innerText.toLowerCase();
        const periodo = cells[3].innerText.toLowerCase();
        const estatus = cells[4].innerText.toLowerCase();
        const area = estudiante.split('(')[1]?.split(')')[0].toLowerCase(); // Extrae el área de interés del texto
        
        const coincideConBusqueda = tutor.includes(buscarInput) || estudiante.includes(buscarInput);
        const coincideConEstatus = estatus.includes(estatusSelect) || estatusSelect === '';
        const coincideConArea = area.includes(areaSelect) || areaSelect === '';
        const coincideConPeriodo = periodo.includes(periodoSelect) || periodoSelect === '';
        const coincideConLinea = estudiante.includes(lineaSelect) || lineaSelect === '';

        if (coincideConBusqueda && coincideConEstatus && coincideConArea && coincideConPeriodo && coincideConLinea) {
            fila.style.display = '';
        } else {
            fila.style.display = 'none';
        }
    });
}

// Función para reajustar los filtros
function reajustarFiltros() {
    document.getElementById('buscar-input-investigaciones').value = '';
    document.getElementById('estatus-select-investigaciones').value = '';
    document.getElementById('area-select-investigaciones').value = '';
    document.getElementById('periodo-aprobacion-select-investigaciones').value = '';
    document.getElementById('linea-investigacion-select-investigaciones').value = '';
    
    // Llamar a la función de filtrado para aplicar los filtros vacíos
    filtrarInvestigaciones();
}

// Evento para el botón de búsqueda
document.querySelector('.btn-buscar-investigaciones').addEventListener('click', filtrarInvestigaciones);

// Evento para el botón de reajustar filtros
document.getElementById('btn-reajustar-investigaciones').addEventListener('click', reajustarFiltros);

// Paginación
const rowsPerPage = 5; // Número de filas por página
let currentPage = 1; // Página actual
let totalRows = 0; // Total de filas
let totalPages = 0; // Total de páginas
const table = document.getElementById('tabla-investigaciones');
const rows = table.getElementsByTagName('tbody')[0].getElementsByTagName('tr');

function updateRowCount() {
    totalRows = rows.length; // Total de filas
    totalPages = Math.ceil(totalRows / rowsPerPage); // Total de páginas
}

function displayRows(page) {
    const start = (page - 1) * rowsPerPage;
    const end = start + rowsPerPage;

    // Ocultar todas las filas
    for (let i = 0; i < rows.length; i++) {
        rows[i].style.display = 'none';
    }

    // Mostrar solo las filas de la página actual
    for (let i = start; i < end && i < totalRows; i++) {
        rows[i].style.display = '';
    }

    // Actualizar la información de paginación
    document.querySelector('.info-paginacion-investigaciones').textContent = `${start + 1}-${Math.min(end, totalRows)} de ${totalRows}`;
}

function updatePaginationButtons() {
    const prevButton = document.querySelector('.pagina-anterior-investigaciones');
    const nextButton = document.querySelector('.pagina-siguiente-investigaciones');
    const pageButtonsContainer = document.querySelector('.numeros-pagina-investigaciones');

    // Habilitar o deshabilitar el botón anterior
    prevButton.disabled = currentPage === 1;

    // Habilitar o deshabilitar el botón siguiente
    nextButton.disabled = currentPage === totalPages;

    // Limpiar los botones de página existentes
    pageButtonsContainer.innerHTML = '';

    // Crear botones de página dinámicamente
    for (let i = 1; i <= totalPages; i++) {
        const button = document.createElement('button');
        button.classList.add('numero-pagina-investigaciones');
        button.textContent = i;
        button.classList.toggle('activo', i === currentPage); // Marcar el botón activo

        // Agregar evento de clic para cambiar de página
        button.addEventListener('click', () => {
            currentPage = i;
            displayRows(currentPage);
            updatePaginationButtons();
        });

        pageButtonsContainer.appendChild(button);
    }
}

document.querySelector('.pagina-anterior-investigaciones').addEventListener('click', () => {
    if (currentPage > 1) {
        currentPage--;
        displayRows(currentPage);
        updatePaginationButtons();
    }
});

document.querySelector('.pagina-siguiente-investigaciones').addEventListener('click', () => {
    if (currentPage < totalPages) {
        currentPage++;
        displayRows(currentPage);
        updatePaginationButtons();
    }
});

// Función de filtrado
function filtrarInvestigaciones() {
    const searchValue = document.getElementById('buscar-input-investigaciones').value.toLowerCase();
    const estatusValue = document.getElementById('estatus-select-investigaciones').value;
    const areaValue = document.getElementById('area-select-investigaciones').value;
    const periodoValue = document.getElementById('periodo-aprobacion-select-investigaciones').value;
    const lineaValue = document.getElementById('linea-investigacion-select-investigaciones').value;
    let visibleRows = 0; 
    
    // Iterar sobre las filas de la tabla
    for (let i = 0; i < rows.length; i++) {
        const row = rows[i];
        const tutor = row.cells[1].textContent.toLowerCase();
        const estudiante = row.cells[2].textContent.toLowerCase();
        const estatus = row.cells[4].textContent.toLowerCase();
        const area = row.cells[2].textContent.toLowerCase(); // Asumiendo que el área está en la columna de estudiante
        const periodo = row.cells[3].textContent.toLowerCase();
        const linea = row.cells[2].textContent.toLowerCase(); // Asumiendo que la línea está en la columna de estudiante

        // Verificar si la fila coincide con los filtros
        const matchesSearch = tutor.includes(searchValue) || estudiante.includes(searchValue);
        const matchesEstatus = estatusValue ? estatus.includes(estatusValue.toLowerCase()) : true;
        const matchesArea = areaValue ? area.includes(areaValue.toLowerCase()) : true;
        const matchesPeriodo = periodoValue ? periodo.includes(periodoValue.toLowerCase()) : true;
        const matchesLinea = lineaValue ? linea.includes(lineaValue.toLowerCase()) : true;

        // Mostrar u ocultar la fila según los filtros
        if (matchesSearch && matchesEstatus && matchesArea && matchesPeriodo && matchesLinea) {
            row.style.display = ''; // Mostrar fila
            visibleRows++;
        } else {
            row.style.display = 'none'; // Ocultar fila
        }
    }

    // Actualizar el conteo de filas y la paginación
    totalRows = visibleRows; // Actualizar el total de filas visibles
    totalPages = Math.ceil(totalRows / rowsPerPage); // Calcular el total de páginas
    currentPage = 1; // Reiniciar a la primera página
    displayRows(currentPage); // Mostrar filas de la primera página
    updatePaginationButtons(); // Actualizar botones de paginación
}

// Inicializar la paginación
updateRowCount();
displayRows(currentPage);
updatePaginationButtons();