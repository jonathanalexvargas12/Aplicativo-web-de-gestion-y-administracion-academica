// Para que se desplieguen los filtros
const btnFiltrarInvestigaciones = document.getElementById('btn-filtrar-investigaciones');
const filtrosBusquedaInvestigaciones = document.getElementById('filtros-busqueda-investigaciones');

btnFiltrarInvestigaciones.addEventListener('click', () => {
    filtrosBusquedaInvestigaciones.classList.toggle('mostrar');
});
// Para que los filtros de busqueda funcionen
const btnBuscarInvestigaciones = document.querySelector('.btn-buscar-investigaciones');
const btnReajustarInvestigaciones = document.getElementById('btn-reajustar-investigaciones');
const buscarInputInvestigaciones = document.getElementById('buscar-input-investigaciones');
const estatusSelectInvestigaciones = document.getElementById('estatus-select-investigaciones');
const areaSelectInvestigaciones = document.getElementById('area-select-investigaciones');
const periodoSelectInvestigaciones = document.getElementById('periodo-aprobacion-select-investigaciones');
const lineaSelectInvestigaciones = document.getElementById('linea-investigacion-select-investigaciones');
const tablaInvestigaciones = document.getElementById('tabla-investigaciones').getElementsByTagName('tbody')[0];

// Función para filtrar la tabla
function filtrarTabla() {
    const buscarTexto = buscarInputInvestigaciones.value.toLowerCase();
    const estatusSeleccionado = estatusSelectInvestigaciones.value;
    const areaSeleccionada = areaSelectInvestigaciones.value;
    const periodoSeleccionado = periodoSelectInvestigaciones.value;
    const lineaSeleccionada = lineaSelectInvestigaciones.value;

    // Obtener todas las filas de la tabla
    const filas = tablaInvestigaciones.getElementsByTagName('tr');

    // Iterar sobre las filas y ocultar las que no coincidan con los filtros
    for (let i = 0; i < filas.length; i++) {
        const celdas = filas[i].getElementsByTagName('td');
        const tutor = celdas[1].textContent.toLowerCase();
        const estudiante = celdas[2].textContent.toLowerCase();
        const periodo = celdas[3].textContent;
        const estatus = celdas[4].textContent.toLowerCase();

        // Comprobar coincidencias
        const coincideBusqueda = tutor.includes(buscarTexto) || estudiante.includes(buscarTexto);
        const coincideEstatus = estatusSeleccionado === "" || estatus.includes(estatusSeleccionado.toLowerCase());
        const coincideArea = areaSeleccionada === "" || (estudiante.includes(areaSeleccionada.toLowerCase()));
        const coincidePeriodo = periodoSeleccionado === "" || periodo.includes(periodoSeleccionado);
        const coincideLinea = lineaSeleccionada === "" || (estudiante.includes(lineaSeleccionada.toLowerCase()));

        // Mostrar u ocultar la fila según los filtros
        if (coincideBusqueda && coincideEstatus && coincideArea && coincidePeriodo && coincideLinea) {
            filas[i].style.display = ""; // Mostrar fila
        } else {
            filas[i].style.display = "none"; // Ocultar fila
        }
    }
    inicializarPaginacionInvestigaciones(); // Re-inicializar paginación después de filtrar
}

// Función para reajustar los filtros
function reajustarFiltros() {
    buscarInputInvestigaciones.value = "";
    estatusSelectInvestigaciones.selectedIndex = 0;
    areaSelectInvestigaciones.selectedIndex = 0;
    periodoSelectInvestigaciones.selectedIndex = 0;
    lineaSelectInvestigaciones.selectedIndex = 0;

    // Volver a mostrar todas las filas
    const filas = tablaInvestigaciones.getElementsByTagName('tr');
    for (let i = 0; i < filas.length; i++) {
        filas[i].style.display = ""; // Mostrar todas las filas
    }
    inicializarPaginacionInvestigaciones(); // Re-inicializar paginación después de reajustar
}

// Agregar eventos a los botones
btnBuscarInvestigaciones.addEventListener('click', filtrarTabla);
btnReajustarInvestigaciones.addEventListener('click', reajustarFiltros);

// Agregar evento de entrada para búsqueda en tiempo real
buscarInputInvestigaciones.addEventListener('input', filtrarTabla);

// Para que la paginacion funcione
function inicializarPaginacionInvestigaciones() {
    const tabla = document.getElementById('tabla-investigaciones').getElementsByTagName('tbody')[0];
    if (!tabla) {
        console.error("No se encontró la tabla.");
        return;
    }

    const filas = Array.from(tabla.getElementsByTagName('tr'));
    const numFilasPorPagina = 5;
    let paginaActual = 1;
    let numPaginas = Math.ceil(filas.length / numFilasPorPagina);

    const numerosPaginaDiv = document.querySelector('.numeros-pagina-investigaciones');
    const infoPaginacionSpan = document.querySelector('.info-paginacion-investigaciones');
    const btnAnterior = document.querySelector('.pagina-anterior-investigaciones');
    const btnSiguiente = document.querySelector('.pagina-siguiente-investigaciones');

    if (!numerosPaginaDiv || !infoPaginacionSpan || !btnAnterior || !btnSiguiente) {
        console.error(" No se encontraron los elementos de paginación.");
        return;
    }

    function mostrarPagina(numPagina) {
        paginaActual = numPagina;
        const inicio = (numPagina - 1) * numFilasPorPagina;
        const fin = Math.min(inicio + numFilasPorPagina, filas.length);

        filas.forEach((fila, index) => {
            fila.style.display = (index >= inicio && index < fin) ? 'table-row' : 'none';
        });

        actualizarNumerosPagina();
        actualizarInfoPaginacion();
    }

    function actualizarNumerosPagina() {
        numerosPaginaDiv.innerHTML = ''; // Limpiar los botones anteriores
        numPaginas = Math.ceil(filas.length / numFilasPorPagina); // Recalcular el número de páginas

        for (let i = 1; i <= numPaginas; i++) {
            const btnNumero = document.createElement('button');
            btnNumero.classList.add('numero-pagina-investigaciones');
            btnNumero.textContent = i;
            btnNumero.dataset.pagina = i;

            if (i === paginaActual) {
                btnNumero.classList.add('activo');
            }

            btnNumero.addEventListener('click', (event) => {
                mostrarPagina(parseInt(event.target.dataset.pagina));
            });

            numerosPaginaDiv.appendChild(btnNumero);
        }
    }

    function actualizarInfoPaginacion() {
        const inicio = (paginaActual - 1) * numFilasPorPagina + 1;
        const fin = Math.min(paginaActual * numFilasPorPagina, filas.length);
        infoPaginacionSpan.textContent = `${inicio}-${fin} de ${filas.length}`;

        btnAnterior.disabled = paginaActual === 1;
        btnSiguiente.disabled = paginaActual === numPaginas || numPaginas === 0; // Manejar el caso de 0 páginas
    }

    btnAnterior.addEventListener('click', () => {
        if (paginaActual > 1) {
            mostrarPagina(paginaActual - 1);
        }
    });

    btnSiguiente.addEventListener('click', () => {
        if (paginaActual < numPaginas) {
            mostrarPagina(paginaActual + 1);
        }
    });

    // Mostrar la primera página al inicializar y actualizar los números de página
    if (filas.length > 0) {
        mostrarPagina(1);
        actualizarNumerosPagina(); // Inicializar los botones de página al cargar
    } else {
        infoPaginacionSpan.textContent = "0-0 de 0"; // Mensaje si no hay filas
        btnAnterior.disabled = true;
        btnSiguiente.disabled = true;
    }
}

// Asegúrate de llamar a inicializarPaginacionInvestigaciones() después de que se cargue el DOM
document.addEventListener('DOMContentLoaded', inicializarPaginacionInvestigaciones);