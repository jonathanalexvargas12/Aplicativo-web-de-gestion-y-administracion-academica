// Para desplegar los criterios de filtrado 

const btnFiltrar = document.querySelector('.boton-crud-calificaciones:first-child'); 
const filtrosBusqueda = document.querySelector('.filtros-busqueda-calificaciones');

btnFiltrar.addEventListener('click', () => {
    filtrosBusqueda.classList.toggle('mostrar');
});