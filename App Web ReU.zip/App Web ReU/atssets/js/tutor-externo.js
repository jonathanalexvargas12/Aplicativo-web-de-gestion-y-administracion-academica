
//Filtros de busqueda y paginacion

document.addEventListener('DOMContentLoaded', () => {
    const tablaTutores = document.getElementById('tabla-tutor').getElementsByTagName('tbody')[0];
    const buscarInputTutores = document.querySelector('.buscar-input-tutor');
    const estatusSelectTutores = document.querySelector('.estatus-select-tutor');
    const btnBuscarTutores = document.querySelector('.btn-buscar-tutor');
    const btnReajustarTutores = document.querySelector('.btn-reajustar-tutor');

    let filasOriginalesTutores = [];

    function guardarFilasOriginales() {
        filasOriginalesTutores = Array.from(tablaTutores.rows).map(row => row.cloneNode(true));
    }

    guardarFilasOriginales();

    function filtrarTablaTutores() {
        const textoBusqueda = buscarInputTutores.value.toLowerCase();
        const estatusSeleccionado = estatusSelectTutores.value.toLowerCase();

        tablaTutores.innerHTML = '';

        filasOriginalesTutores.forEach(filaOriginal => {
            const fechaSolicitud = filaOriginal.cells[1].textContent.toLowerCase();
            const tutorSolicitar = filaOriginal.cells[2].textContent.toLowerCase();
            const solicitadoPor = filaOriginal.cells[3].textContent.toLowerCase();
            const estatusTexto = filaOriginal.cells[4].textContent.trim().toLowerCase();

            const coincideBusqueda = textoBusqueda === '' ||
                fechaSolicitud.includes(textoBusqueda) ||
                tutorSolicitar.includes(textoBusqueda) ||
                solicitadoPor.includes(textoBusqueda);
            const coincideEstatus = estatusSeleccionado === 'todos' || estatusSeleccionado === '' || estatusTexto.includes(estatusSeleccionado);

            if (coincideBusqueda && coincideEstatus) {
                tablaTutores.appendChild(filaOriginal.cloneNode(true));
            }
        });

        inicializarPaginacionTutores();
    }

    function inicializarPaginacionTutores() {
        const filas = Array.from(tablaTutores.getElementsByTagName('tr'));
        const numFilasPorPagina = 5;
        let paginaActual = 1;
        let numPaginas = Math.ceil(filas.length / numFilasPorPagina);

        const numerosPaginaDiv = document.querySelector('.numeros-pagina-tutor');
        const infoPaginacionSpan = document.querySelector('.info-paginacion-tutor');
        const btnAnterior = document.querySelector('.pagina-anterior-tutor');
        const btnSiguiente = document.querySelector('.pagina-siguiente-tutor');

        if (!numerosPaginaDiv || !infoPaginacionSpan || !btnAnterior || !btnSiguiente) return;

        function mostrarPagina(numPagina) {
            paginaActual = numPagina;
            const inicio = (numPagina - 1) * numFilasPorPagina;
            const fin = Math.min(inicio + numFilasPorPagina, filas.length);

            filas.forEach((fila, index) => {
                fila.style.display = (index >= inicio && index < fin) ? 'table-row' : 'none';
            });

            actualizarNumerosPagina();
            actualizarInfoPaginacion();
        }

        function actualizarNumerosPagina() {
            numerosPaginaDiv.innerHTML = '';
            numPaginas = Math.ceil(filas.length / numFilasPorPagina);

            for (let i = 1; i <= numPaginas; i++) {
                const btnNumero = document.createElement('button');
                btnNumero.classList.add('numero-pagina-tutor');
                btnNumero.textContent = i;
                btnNumero.dataset.pagina = i;

                if (i === paginaActual) {
                    btnNumero.classList.add('activo');
                }

                btnNumero.addEventListener('click', (event) => {
                    mostrarPagina(parseInt(event.target.dataset.pagina));
                });

                numerosPaginaDiv.appendChild(btnNumero);
            }
        }

        function actualizarInfoPaginacion() {
            const inicio = (paginaActual - 1) * numFilasPorPagina + 1;
            const fin = Math.min(paginaActual * numFilasPorPagina, filas.length);
            infoPaginacionSpan.textContent = `${inicio}-${fin} de ${filas.length}`;

            btnAnterior.disabled = paginaActual === 1;
            btnSiguiente.disabled = paginaActual === numPaginas || numPaginas === 0;
        }

        btnAnterior.addEventListener('click', () => {
            if (paginaActual > 1) {
                mostrarPagina(paginaActual - 1);
            }
        });

        btnSiguiente.addEventListener('click', () => {
            if (paginaActual < numPaginas) {
                mostrarPagina(paginaActual + 1);
            }
        });

        if (filas.length > 0) {
            mostrarPagina(1);
            actualizarNumerosPagina();
        } else {
            infoPaginacionSpan.textContent = "0-0 de 0";
            btnAnterior.disabled = true;
            btnSiguiente.disabled = true;
        }
    }

    btnReajustarTutores.addEventListener('click', () => {
        buscarInputTutores.value = '';
        estatusSelectTutores.selectedIndex = 0;
        tablaTutores.innerHTML = '';
        filasOriginalesTutores.forEach(fila => tablaTutores.appendChild(fila.cloneNode(true)));
        inicializarPaginacionTutores();
    });

    btnBuscarTutores.addEventListener('click', filtrarTablaTutores);

    inicializarPaginacionTutores();
});
