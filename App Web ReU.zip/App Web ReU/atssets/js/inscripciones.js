// Para desplegar los criterios de filtrado del crud

const btnFiltrar = document.getElementById('btn-filtrar');
const filtrosBusqueda = document.getElementById('filtros-busqueda');

btnFiltrar.addEventListener('click', () => {
    filtrosBusqueda.classList.toggle('mostrar');
});


// Para restablecer los criterios de filtrado del crud

const btnReajustar = document.getElementById('btn-reajustar');
    const buscarInput = document.getElementById('buscar-input');
    const periodoSelect = document.getElementById('periodo-select');
    const estadoSelect = document.getElementById('estado-select');
    const pagoSelect = document.getElementById('pago-select');

    btnReajustar.addEventListener('click', () => {
       
        buscarInput.value = '';

       
        periodoSelect.selectedIndex = 0; 
        estadoSelect.selectedIndex = 0;
        pagoSelect.selectedIndex = 0;
    });

// Para que la paginación del crud funcione y se muestre de 5 filas en 5 filas
 
const tabla = document.getElementById('tabla-estudiantes').getElementsByTagName('tbody')[0];
const filas = tabla.getElementsByTagName('tr');
const numFilasPorPagina = 5;
let paginaActual = 1;
let numPaginas = Math.ceil(filas.length / numFilasPorPagina);
const numerosPaginaDiv = document.querySelector('.numeros-pagina');
const infoPaginacionSpan = document.querySelector('.info-paginacion');
const btnAnterior = document.querySelector('.pagina-anterior');
const btnSiguiente = document.querySelector('.pagina-siguiente');

function mostrarPagina(numPagina) {
    paginaActual = numPagina;
    const inicio = (numPagina - 1) * numFilasPorPagina;
    const fin = inicio + numFilasPorPagina;

    for (let i = 0; i < filas.length; i++) {
        filas[i].style.display = 'none'; 
        if (i >= inicio && i < fin) {
            filas[i].style.display = ''; 
        }
    }

    actualizarNumerosPagina();
    actualizarInfoPaginacion();
}

function actualizarNumerosPagina() {
    numerosPaginaDiv.innerHTML = ''; 

    for (let i = 1; i <= numPaginas; i++) {
        const btnNumero = document.createElement('button');
        btnNumero.classList.add('numero-pagina');
        btnNumero.textContent = i;
        if (i === paginaActual) {
            btnNumero.classList.add('activo');
        }
        btnNumero.addEventListener('click', () => mostrarPagina(i));
        numerosPaginaDiv.appendChild(btnNumero);
    }
}

function actualizarInfoPaginacion() {
    const inicio = (paginaActual - 1) * numFilasPorPagina + 1;
    const fin = Math.min(paginaActual * numFilasPorPagina, filas.length);
    infoPaginacionSpan.textContent = `${inicio}-${fin} de ${filas.length}`;

    btnAnterior.disabled = paginaActual === 1;
    btnSiguiente.disabled = paginaActual === numPaginas;
}

btnAnterior.addEventListener('click', () => {
    if (paginaActual > 1) {
        mostrarPagina(paginaActual - 1);
    }
});

btnSiguiente.addEventListener('click', () => {
    if (paginaActual < numPaginas) {
        mostrarPagina(paginaActual + 1);
    }
});


mostrarPagina(1);


