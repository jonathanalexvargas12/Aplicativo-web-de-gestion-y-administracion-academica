// Para desplegar los criterios de filtrado del crud

const btnFiltrar = document.getElementById('btn-filtrar');
const filtrosBusqueda = document.getElementById('filtros-busqueda');

btnFiltrar.addEventListener('click', () => {
    filtrosBusqueda.classList.toggle('mostrar');
});


// Para buscar coincidencias con el filtro

document.addEventListener('DOMContentLoaded', () => {
    const tablaEstudiantes = document.getElementById('tabla-estudiantes').getElementsByTagName('tbody')[0];
    const buscarInput = document.getElementById('buscar-input');
    const periodoSelect = document.getElementById('periodo-select');
    const estadoSelect = document.getElementById('estado-select');
    const pagoSelect = document.getElementById('pago-select');
    const botonBuscar = document.querySelector('.botones-filtro .boton-filtro');
    const btnReajustar = document.getElementById('btn-reajustar');

    const filasOriginales = Array.from(tablaEstudiantes.rows); // Guarda las filas originales

    function filtrarTabla() {
        const textoBusqueda = buscarInput.value.toLowerCase();
        const periodoSeleccionado = periodoSelect.value;
        const estadoSeleccionado = estadoSelect.value;
        const pagoSeleccionado = pagoSelect.value;

        // Limpia la tabla
        tablaEstudiantes.innerHTML = '';

        filasOriginales.forEach(fila => {
            const cedula = fila.cells[1].textContent.toLowerCase();
            const nombres = fila.cells[2].textContent.toLowerCase();
            const apellidos = fila.cells[3].textContent.toLowerCase();
            const carrera = fila.cells[4].textContent.toLowerCase();
            const periodo = fila.cells[6].textContent;
            const estado = fila.cells[8].querySelector('i').classList.contains('estado-activo') ? 'activo' : 'inactivo';
            const pago = fila.cells[9].querySelector('i').classList.contains('pago-realizado') ? 'realizado' : 'pendiente';

            const coincideBusqueda = textoBusqueda === '' ||
                                        cedula.includes(textoBusqueda) ||
                                        nombres.includes(textoBusqueda) ||
                                        apellidos.includes(textoBusqueda) ||
                                        carrera.includes(textoBusqueda);
            const coincidePeriodo = periodoSeleccionado === '' || periodo === periodoSeleccionado;
            const coincideEstado = estadoSeleccionado === '' || estado === estadoSeleccionado;
            const coincidePago = pagoSeleccionado === '' || pago === pagoSeleccionado;

            if (coincideBusqueda && coincidePeriodo && coincideEstado && coincidePago) {
                tablaEstudiantes.appendChild(fila.cloneNode(true)); // Añade una copia de la fila
            }
        });

        // Actualizar la paginación después de filtrar
        actualizarPaginacion();
    }

    botonBuscar.addEventListener('click', filtrarTabla);

    btnReajustar.addEventListener('click', () => {
        buscarInput.value = '';
        periodoSelect.selectedIndex = 0;
        estadoSelect.selectedIndex = 0;
        pagoSelect.selectedIndex = 0;
        tablaEstudiantes.innerHTML = '';
        filasOriginales.forEach(fila => tablaEstudiantes.appendChild(fila.cloneNode(true)));
        actualizarPaginacion();
    });

    // Para restablecer los criterios de filtrado del CRUD
    btnReajustar.addEventListener('click', () => {
        buscarInput.value = '';
        periodoSelect.selectedIndex = 0; 
        estadoSelect.selectedIndex = 0;
        pagoSelect.selectedIndex = 0;
    });

    // Para que la paginación del CRUD funcione y se muestre de 5 filas en 5 filas
    const numFilasPorPagina = 5;
    let paginaActual = 1;

    function actualizarPaginacion() {
        const filas = Array.from(tablaEstudiantes.rows);
        const numPaginas = Math.ceil(filas.length / numFilasPorPagina);
        
        mostrarPagina(paginaActual);

        // Actualizar números de página
        const numerosPaginaDiv = document.querySelector('.numeros-pagina');
        numerosPaginaDiv.innerHTML = '';
        for (let i = 1; i <= numPaginas; i++) {
            const btnNumero = document.createElement('button');
            btnNumero.classList.add('numero-pagina');
            btnNumero.textContent = i;
            if (i === paginaActual) {
                btnNumero.classList.add('activo');
            }
            btnNumero.addEventListener('click', () => mostrarPagina(i));
            numerosPaginaDiv.appendChild(btnNumero);
        }
    }

    function mostrarPagina(numPagina) {
        const filas = Array.from(tablaEstudiantes.rows);
        paginaActual = numPagina;
        const inicio = (numPagina - 1) * numFilasPorPagina;
        const fin = inicio + numFilasPorPagina;

        filas.forEach((fila, index) => {
            fila.style.display = (index >= inicio && index < fin) ? '' : 'none';
        });

        actualizarInfoPaginacion();
    }

    function actualizarInfoPaginacion() {
        const filas = Array.from(tablaEstudiantes.rows);
        const inicio = (paginaActual - 1) * numFilasPorPagina + 1;
        const fin = Math.min(paginaActual * numFilasPorPagina, filas.length);
        const infoPaginacionSpan = document.querySelector('.info-paginacion');
        infoPaginacionSpan.textContent = `${inicio}-${fin} de ${filas.length}`;

        const btnAnterior = document.querySelector('.pagina-anterior');
        const btnSiguiente = document.querySelector('.pagina-siguiente');
        btnAnterior.disabled = paginaActual === 1;
        btnSiguiente.disabled = paginaActual === Math.ceil(filas.length / numFilasPorPagina);
    }

    const btnAnterior = document.querySelector('.pagina-anterior');
    const btnSiguiente = document.querySelector('.pagina-siguiente');

    btnAnterior.addEventListener('click', () => {
        if (paginaActual > 1) {
            mostrarPagina(paginaActual - 1);
        }
    });

    btnSiguiente.addEventListener('click', () => {
        if (paginaActual < Math.ceil(tablaEstudiantes.rows.length / numFilasPorPagina)) {
            mostrarPagina(paginaActual + 1);
        }
    });

    // Inicializar la paginación al cargar la página
    mostrarPagina(1);
});


// Ventana modal "Agregar" del crud estudiante


        const agregarModal = document.getElementById("agregarModal");
        const agregarModalForm = document.getElementById("agregar-modal-form");
        const agregarSpan = document.getElementsByClassName("agregar-close")[0];
        const cancelarAgregarModal = document.getElementById("cancelar-agregar-modal");
        const btnAgregar = document.getElementById("btn-agregar");

        btnAgregar.addEventListener("click", () => {
            agregarModal.style.display = "block";
        });

        agregarSpan.onclick = function() {
            agregarModal.style.display = "none";
        }
        cancelarAgregarModal.onclick = function(){
            agregarModal.style.display = "none";
        }

        window.onclick = function(event) {
            if (event.target == agregarModal) {
                agregarModal.style.display = "none";
            }
        }
        agregarModalForm.addEventListener('submit', (event) => {
            event.preventDefault();
             //Aquí deberías agregar la lógica para enviar los datos al servidor
            agregarModal.style.display = "none";
        });


// Ventana modal "Editar" del crud estudiante

const modal = document.getElementById("myModal");
        const modalForm = document.getElementById("modal-form");
        const span = document.getElementsByClassName("close")[0];
        const cancelarModal = document.getElementById("cancelar-modal");
        const editIcons = document.querySelectorAll(".fa-edit");
        let currentRow;

        editIcons.forEach(icon => {
            icon.addEventListener("click", (event) => {
                modal.style.display = "block";
                currentRow = event.target.closest("tr"); // Obtener la fila actual
                populateModal(currentRow);
            });
        });

        span.onclick = function() {
            modal.style.display = "none";
        }
        cancelarModal.onclick = function(){
            modal.style.display = "none";
        }

        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }

        function populateModal(row) {
            const cells = row.querySelectorAll("td");
            document.getElementById("cedula").value = cells[1].textContent;
            document.getElementById("nombres").value = cells[2].textContent;
            document.getElementById("apellidos").value = cells[3].textContent;
            document.getElementById("carrera").value = cells[4].textContent;
            document.getElementById("pensum").value = cells[5].textContent;
            document.getElementById("periodo").value = cells[6].textContent;
            document.getElementById("fecha").value = formatDate(cells[7].textContent);
            document.getElementById("estado").value = cells[8].querySelector("i").classList.contains("estado-activo") ? "activo" : "inactivo";
            document.getElementById("pago").value = cells[9].querySelector("i").classList.contains("pago-realizado") ? "realizado" : "pendiente";
        }
        function formatDate(dateString) {
            const parts = dateString.split('-');
            return `${parts[2]}-${parts[1]}-${parts[0]}`;
        }
        modalForm.addEventListener('submit', (event) => {
            event.preventDefault();
            const cells = currentRow.querySelectorAll("td");
            cells[1].textContent = document.getElementById("cedula").value;
            cells[2].textContent = document.getElementById("nombres").value;
            cells[3].textContent = document.getElementById("apellidos").value;
            cells[4].textContent = document.getElementById("carrera").value;
            cells[5].textContent = document.getElementById("pensum").value;
            cells[6].textContent = document.getElementById("periodo").value;
            cells[7].textContent = document.getElementById("fecha").value;
            const estadoIcon = cells[8].querySelector("i");
            estadoIcon.classList.remove("estado-activo", "estado-inactivo");
            estadoIcon.classList.add(document.getElementById("estado").value === "activo" ? "estado-activo" : "estado-inactivo");
            const pagoIcon = cells[9].querySelector("i");
            pagoIcon.classList.remove("pago-realizado", "pago-pendiente");
            pagoIcon.classList.add(document.getElementById("pago").value === "realizado" ? "pago-realizado" : "pago-pendiente");
            modal.style.display = "none";
        });


        // Ventana modal de anular el crud

        const modalAnular = document.getElementById("modalAnular");
        const btnAnular = document.querySelectorAll(".fa-ban");
        const spanCerrarAnular = document.getElementsByClassName("close-anular")[0];

        btnAnular.forEach(btn => {
            btn.onclick = function() {
                modalAnular.style.display = "block";
            }
        });

        spanCerrarAnular.onclick = function() {
            modalAnular.style.display = "none";
        }

        document.getElementById("btn-cancelar-anular").onclick = function() {
            modalAnular.style.display = "none";
        }

        window.onclick = function(event) {
            if (event.target == modalAnular) {
                modalAnular.style.display = "none";
            }
        }