//Paginacion y filtrado

document.addEventListener('DOMContentLoaded', () => {
    const tablaSolicitudes = document.getElementById('tabla-solicitudes').getElementsByTagName('tbody')[0];
    const buscarInputSolicitudes = document.querySelector('.buscar-input-solicitudes');
    const estatusSelectSolicitudes = document.querySelector('.estatus-select-solicitudes');
    const btnBuscarSolicitudes = document.querySelector('.btn-buscar-solicitudes');
    const btnReajustarSolicitudes = document.querySelector('.btn-reajustar-solicitudes');

    let filasOriginalesSolicitudes = [];

    function guardarFilasOriginales() {
        filasOriginalesSolicitudes = Array.from(tablaSolicitudes.rows).map(row => row.cloneNode(true));
    }

    guardarFilasOriginales();

    function filtrarTablaSolicitudes() {
        const textoBusqueda = buscarInputSolicitudes.value.toLowerCase();
        const estatusSeleccionado = estatusSelectSolicitudes.value;

        tablaSolicitudes.innerHTML = '';

        filasOriginalesSolicitudes.forEach(filaOriginal => {
            const fechaSolicitud = filaOriginal.cells[1].textContent.toLowerCase();
            const tutorSolicitar = filaOriginal.cells[2].textContent.toLowerCase();
            const solicitadoPor = filaOriginal.cells[3].textContent.toLowerCase();
            const estatusTexto = filaOriginal.cells[4].textContent.trim().toLowerCase();

            const coincideBusqueda = textoBusqueda === '' ||
                fechaSolicitud.includes(textoBusqueda) ||
                tutorSolicitar.includes(textoBusqueda) ||
                solicitadoPor.includes(textoBusqueda);
            const coincideEstatus = estatusSeleccionado === '' || estatusTexto.includes(estatusSeleccionado);

            if (coincideBusqueda && coincideEstatus) {
                tablaSolicitudes.appendChild(filaOriginal.cloneNode(true));
            }
        });
        inicializarPaginacionTutoria(); // Reinicializar la paginación después de filtrar
    }

    function inicializarPaginacionTutoria() {
        const tabla = document.getElementById('tabla-solicitudes').getElementsByTagName('tbody')[0];
        if (!tabla) return;

        const filas = Array.from(tabla.getElementsByTagName('tr'));
        const numFilasPorPagina = 5;
        let paginaActual = 1;
        let numPaginas = Math.ceil(filas.length / numFilasPorPagina);

        const numerosPaginaDiv = document.querySelector('.numeros-pagina-tutoria');
        const infoPaginacionSpan = document.querySelector('.info-paginacion-tutoria');
        const btnAnterior = document.querySelector('.pagina-anterior-tutoria');
        const btnSiguiente = document.querySelector('.pagina-siguiente-tutoria');

        if (!numerosPaginaDiv || !infoPaginacionSpan || !btnAnterior || !btnSiguiente) return;

        function mostrarPagina(numPagina) {
            paginaActual = numPagina;
            const inicio = (numPagina - 1) * numFilasPorPagina;
            const fin = Math.min(inicio + numFilasPorPagina, filas.length);

            filas.forEach((fila, index) => {
                fila.style.display = (index >= inicio && index < fin) ? 'table-row' : 'none';
            });

            actualizarNumerosPagina();
            actualizarInfoPaginacion();
        }

        function actualizarNumerosPagina() {
            numerosPaginaDiv.innerHTML = '';
            numPaginas = Math.ceil(filas.length / numFilasPorPagina);

            for (let i = 1; i <= numPaginas; i++) {
                const btnNumero = document.createElement('button');
                btnNumero.classList.add('numero-pagina-tutoria');
                btnNumero.textContent = i;
                btnNumero.dataset.pagina = i;

                if (i === paginaActual) {
                    btnNumero.classList.add('activo');
                }

                btnNumero.addEventListener('click', (event) => {
                    mostrarPagina(parseInt(event.target.dataset.pagina));
                });

                numerosPaginaDiv.appendChild(btnNumero);
            }
        }

        function actualizarInfoPaginacion() {
            const inicio = (paginaActual - 1) * numFilasPorPagina + 1;
            const fin = Math.min(paginaActual * numFilasPorPagina, filas.length);
            infoPaginacionSpan.textContent = `${inicio}-${fin} de ${filas.length}`;

            btnAnterior.disabled = paginaActual === 1;
            btnSiguiente.disabled = paginaActual === numPaginas || numPaginas === 0;
        }

        btnAnterior.addEventListener('click', () => {
            if (paginaActual > 1) {
                mostrarPagina(paginaActual - 1);
            }
        });

        btnSiguiente.addEventListener('click', () => {
            if (paginaActual < numPaginas) {
                mostrarPagina(paginaActual + 1);
            }
        });

        if (filas.length > 0) {
            mostrarPagina(1);
            actualizarNumerosPagina();
        } else {
            infoPaginacionSpan.textContent = "0-0 de 0";
            btnAnterior.disabled = true;
            btnSiguiente.disabled = true;
        }
    }

    btnReajustarSolicitudes.addEventListener('click', () => {
        buscarInputSolicitudes.value = '';
        estatusSelectSolicitudes.selectedIndex = 0;
        tablaSolicitudes.innerHTML = '';
        filasOriginalesSolicitudes.forEach(fila => tablaSolicitudes.appendChild(fila.cloneNode(true)));
        inicializarPaginacionTutoria(); // Reinicializar la paginación después de reajustar
    });

    btnBuscarSolicitudes.addEventListener('click', filtrarTablaSolicitudes);
    buscarInputSolicitudes.addEventListener('input', filtrarTablaSolicitudes);
    estatusSelectSolicitudes.addEventListener('change', filtrarTablaSolicitudes);

    inicializarPaginacionTutoria();// Inicializar la paginación al cargar la página

});