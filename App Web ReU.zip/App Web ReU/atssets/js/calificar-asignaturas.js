// Para que los filtros de busqueda se muestren

    const btnFiltrarCalificar = document.getElementById('btn-filtrar-calificar');
    const filtrosBusquedaCalificar = document.getElementById('filtros-busqueda-calificar');

    btnFiltrarCalificar.addEventListener('click', () => {
        filtrosBusquedaCalificar.classList.toggle('mostrar');
    });