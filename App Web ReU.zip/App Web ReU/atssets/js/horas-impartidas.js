// Para desplegar los criterios de filtrado 

const btnFiltrar = document.querySelector('.boton-crud-horas-impartidas:first-child'); 
const filtrosBusqueda = document.querySelector('.filtros-busqueda-horas-impartidas');

btnFiltrar.addEventListener('click', () => {
    filtrosBusqueda.classList.toggle('mostrar');
});
